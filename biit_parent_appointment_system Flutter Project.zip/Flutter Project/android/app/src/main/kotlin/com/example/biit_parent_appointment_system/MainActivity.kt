package com.example.biit_parent_appointment_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
