import 'dart:convert';

import 'package:biit_parent_appointment_system/Models/AttendanceModel.dart';
import 'package:biit_parent_appointment_system/Models/CGPAModel.dart';
import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Student_Attendance.dart';
import 'Student_CGPA.dart';

class StudentDashboard extends StatefulWidget {
  final UserData user;
  const StudentDashboard({Key? key, required this.user}) : super(key: key);

  @override
  State<StudentDashboard> createState() => StudentDashboardState();
}

class StudentDashboardState extends State<StudentDashboard> {
//=====API Variables=====
  List<AttendanceModel> attendance = [];
  bool success = false;
  String errormsg = '';
  late CGPAModel cgpa;

  //========= API ========================
  Future<void> getAttendance(String regno) async {
    String url = '${Variables.baseurl}/Student/getAttendance?regno=$regno';
    print(url);
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      print('successfully called ');
      print(response.body);
      print('Decoding ');
      Iterable listt = jsonDecode(response.body);
      attendance = listt.map((e) => AttendanceModel.fromJson(e)).toList();
      setState(() {
        success = true;
      });
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }
// ==== Get CGPA ===========================

  Future<void> getCGPA(String regno) async {
    String url = '${Variables.baseurl}/Student/CGPA?regno=$regno';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      print('successfully called ');
      print(response.body);
      print('Decoding ');
      cgpa = CGPAModel.fromJson(jsonDecode(response.body));
      setState(() {
        success = true;
      });
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }
  //============== End API ===================

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('Welcome '),
          Text(
            widget.user.username,
            style: const TextStyle(
                fontSize: 22.0,
                fontWeight: FontWeight.bold,
                color: Colors.black),
          )
        ]),
        centerTitle: true,
        titleSpacing: 00.0,
        toolbarHeight: 60.2,
        toolbarOpacity: 0.8,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(25),
              bottomLeft: Radius.circular(25)),
        ),
        elevation: 0.00,
        backgroundColor: Colors.greenAccent[400],
      ),
      body: WillPopScope(
        onWillPop: () => showLogOutDialog(context),
        child: SingleChildScrollView(
          child: Container(
            height: myheight * 0.70,
            alignment: Alignment.center,
            margin: EdgeInsets.only(top: mywidth * 0.06),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                SizedBox(
                  height: spaceheight,
                ),
                //====================
                getCardWithImage(
                  myheight,
                  mywidth,
                  "View Attendance",
                  'assets/images/attendance.png',
                  () async {
                    await getAttendance(widget.user.regno);
                    if (success) {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (cont) =>
                              StudentAttendance(attendance: attendance),
                        ),
                      );
                    } else {
                      showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (cont) {
                            return AlertDialog(
                              title: const Text("Alert!"),
                              content: Text(errormsg),
                              actions: [
                                TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text("Ok")),
                              ],
                            );
                          });
                    }
                  },
                ),
                SizedBox(
                  height: spaceheight,
                ),
                //====================
                getCardWithImage(
                  myheight,
                  mywidth,
                  "View CGPA",
                  'assets/images/cgpa.png',
                  () async {
                    await getCGPA(widget.user.regno);
                    if (success) {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (cont) => StudentCGPA(cgpa: cgpa),
                        ),
                      );
                    } else {
                      showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (cont) {
                            return AlertDialog(
                              title: const Text("Alert!"),
                              content: Text(errormsg),
                              actions: [
                                TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text("Ok")),
                              ],
                            );
                          });
                    }
                  },
                ),
                //====================
              ],
            ),
          ),
        ),
      ),
    );
  }
}
