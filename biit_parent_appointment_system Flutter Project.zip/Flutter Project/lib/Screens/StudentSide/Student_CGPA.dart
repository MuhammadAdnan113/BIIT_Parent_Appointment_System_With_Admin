import 'package:biit_parent_appointment_system/Models/CGPAModel.dart';
import 'package:flutter/material.dart';

class StudentCGPA extends StatefulWidget {
  final CGPAModel cgpa;
  const StudentCGPA({Key? key, required this.cgpa}) : super(key: key);

  @override
  State<StudentCGPA> createState() => StudentCGPAState();
}

class StudentCGPAState extends State<StudentCGPA> {
  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('CGPA'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Your CGPA:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                width: spacewidth,
              ),
              Text('${widget.cgpa.cgpa}'),
            ],
          ),
        ],
      ),
    );
  }
}
