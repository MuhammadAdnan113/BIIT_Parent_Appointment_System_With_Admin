import 'package:biit_parent_appointment_system/Models/AttendanceModel.dart';
import 'package:flutter/material.dart';

class StudentAttendance extends StatefulWidget {
  List<AttendanceModel>? attendance;
  StudentAttendance({Key? key, required this.attendance}) : super(key: key);

  @override
  State<StudentAttendance> createState() => StudentAttendanceState();
}

class StudentAttendanceState extends State<StudentAttendance> {
  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance Record'),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: myheight,
          margin: EdgeInsets.all(spacewidth),
          child: ListView.builder(
            itemCount: widget.attendance!.length,
            itemBuilder: ((context, index) {
              AttendanceModel item = widget.attendance!.elementAt(index);
              return Column(
                children: [
                  Row(
                    children: [
                      const Text(
                        'Reg. No:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.regNo)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Class:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.class1)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Section:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text('${item.semester}-${item.section}')
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Subject:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.subject)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Attendance:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text('${item.percentage}%')
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  const Divider(
                    thickness: 2,
                  ),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
