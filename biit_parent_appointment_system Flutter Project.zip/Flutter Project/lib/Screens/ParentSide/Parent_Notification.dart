import 'dart:convert';
import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Screens/ParentSide/Parent_Appointment.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class ParentNotification extends StatefulWidget {
  List<NotificationModel> notification;
  ParentNotification({Key? key, required this.notification}) : super(key: key);

  @override
  State<ParentNotification> createState() => _ParentNotificationState();
}

class _ParentNotificationState extends State<ParentNotification> {
  // Variables   ======
  DateTime? pickedDate;
  String formattedDate = '';
  var now = DateTime.now();
  var formatter = DateFormat('d/M/yyyy');

  String errormsg = "";
  int _statuscode = 0;
  //==== API =========
  // Future<void> rescheduleAppointment(int tsid, String newdate) async {
  //   String url =
  //       '${Variables.baseurl}/Parent/ReSheduleMeeting?tsid=$tsid&date=$newdate&from=Notification';
  //   var response = await http.get(Uri.parse(url));
  //   setState(() {
  //     errormsg = response.body;
  //   });
  // }

  Future<void> apiPutWaitingList(int tsid, String regno, String reason,
      String status, String date, String adminid, String parentid) async {
    String url = '${Variables.baseurl}/Parent/InsertWaitingList';
    var response = await http.post(Uri.parse(url), body: {
      "tsId": tsid.toString(),
      "regNo": regno,
      "date": date,
      "reason": reason,
      "parentId": parentid,
      "adminId": adminid,
      "status": "Waiting"
    });
    print(response.body);
    _statuscode = response.statusCode;
    if (response.statusCode == 200) {
      await getAlertDialog(context, "Alert", response.body);
      Navigator.of(context).pop();
    } else {
      await getAlertDialog(context, "Alert", response.body);
    }
  }

  //=====================
  bool updated = false;
  Future<void> apiUpdateMeetingStatus(int mid, String status) async {
    String url =
        '${Variables.baseurl}/Parent/UpdateMeetingStatus?mid=$mid&status=$status';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      await getAlertDialog(context, "Alert", response.body);
      setState(() {
        updated = true;
      });
    } else {
      await getAlertDialog(context, "Alert", response.body);
    }
  }

  List<TimeSlot> timelist = [];
  Future<void> apiGetTimeSlot(String date) async {
    String url = '${Variables.baseurl}/Parent/GetTimeSlot?date=$date';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      timelist = listt.map((e) => TimeSlot.fromMap(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  // View Code ===========
  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Parent Notification'),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: myheight * 0.87,
          margin: EdgeInsets.all(spacewidth),
          child: ListView.builder(
            itemCount: widget.notification.length,
            itemBuilder: ((context, index) {
              NotificationModel item = widget.notification.elementAt(index);
              return Column(
                children: [
                  Row(
                    children: [
                      const Text(
                        'Reg. No:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.regNo)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Reason:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.reason)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Date:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.date)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Start Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.startTime)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'End Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.endTime),
                    ],
                  ),
                  item.status == "Wait"
                      ? Column(
                          children: [
                            const Text(
                              "Admin requested either Wait OR Reschedule Appointment",
                              style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.w700),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                ElevatedButton.icon(
                                  onPressed: () async {
                                    await apiPutWaitingList(
                                        item.tsid,
                                        item.regNo,
                                        item.reason,
                                        item.status,
                                        item.date,
                                        item.admin,
                                        item.pid);
                                    if (_statuscode == 200) {
                                      widget.notification.remove(item);
                                      setState(() {});
                                    }
                                  },
                                  icon: const Icon(Icons.watch_later),
                                  label: const Text("Wait"),
                                ),
                                SizedBox(
                                  width: spacewidth * 0.30,
                                ),
                                ElevatedButton.icon(
                                  onPressed: () async {
                                    List<String> reg = [];
                                    List<String> issuesList = [];
                                    String formattedDate =
                                        formatter.format(now);
                                    reg.add(item.regNo);
                                    issuesList.add(item.reason);
                                    await apiGetTimeSlot(formattedDate);
                                    // Going to next Screen
                                    Navigator.of(context).pushReplacement(
                                        MaterialPageRoute(
                                            builder: (cont) =>
                                                ParentAppointment(
                                                  reglist: reg,
                                                  timelist: timelist,
                                                  issues: issuesList,
                                                  mid: item.nid,
                                                )));
                                  },
                                  icon: const Icon(Icons.calendar_month),
                                  label: const Text("Reschecule"),
                                ),
                              ],
                            ),
                          ],
                        )
                      : item.status == "Request"
                          ? Column(
                              children: [
                                const Text(
                                  "Admin requested for an Appointment",
                                  style: TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.w700),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    ElevatedButton.icon(
                                      onPressed: () async {
                                        await apiUpdateMeetingStatus(
                                            item.nid, "Pending");
                                        if (updated) {
                                          item.status = "Pending";
                                          setState(() {});
                                        }
                                      },
                                      icon: const Icon(Icons.check_sharp),
                                      label: const Text("Accept"),
                                    ),
                                    ElevatedButton.icon(
                                      onPressed: (() async {
                                        List<String> reg = [];
                                        List<String> issuesList = [];
                                        String formattedDate =
                                            formatter.format(now);
                                        reg.add(item.regNo);
                                        issuesList.add(item.reason);
                                        await apiGetTimeSlot(formattedDate);
                                        // Going to next Screen
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder: (cont) =>
                                                    ParentAppointment(
                                                      reglist: reg,
                                                      timelist: timelist,
                                                      issues: issuesList,
                                                      mid: item.nid,
                                                    )));
                                        // end
                                      }),
                                      icon: const Icon(Icons.close_sharp),
                                      label: const Text("Reject"),
                                    ),
                                  ],
                                )
                              ],
                            )
                          : item.status == "Reschedualed"
                              ? Column(
                                  children: [
                                    const Text(
                                      "Your Appointment is Recheduled by Admin",
                                      style: TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        ElevatedButton.icon(
                                          onPressed: () async {
                                            await apiUpdateMeetingStatus(
                                                item.nid, "Pending");
                                            if (updated) {
                                              item.status = "Pending";
                                              setState(() {});
                                            }
                                          },
                                          icon: const Icon(Icons.check_sharp),
                                          label: const Text("Accept"),
                                        ),
                                        ElevatedButton.icon(
                                          onPressed: (() async {
                                            List<String> reg = [];
                                            List<String> issuesList = [];
                                            String formattedDate =
                                                formatter.format(now);
                                            reg.add(item.regNo);
                                            issuesList.add(item.reason);
                                            await apiGetTimeSlot(formattedDate);
                                            // Going to next Screen
                                            Navigator.of(context)
                                                .pushReplacement(
                                                    MaterialPageRoute(
                                                        builder: (cont) =>
                                                            ParentAppointment(
                                                              reglist: reg,
                                                              timelist:
                                                                  timelist,
                                                              issues:
                                                                  issuesList,
                                                              mid: item.nid,
                                                            )));
                                            // end
                                          }),
                                          icon: const Icon(Icons.close_sharp),
                                          label: const Text("Reject"),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                              : SizedBox(
                                  height: spaceheight * 0.30,
                                ),
                  const Divider(
                    thickness: 2,
                  ),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
