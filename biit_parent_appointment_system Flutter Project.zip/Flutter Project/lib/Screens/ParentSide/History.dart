import 'dart:convert';

import 'package:biit_parent_appointment_system/Models/Feedback.dart';
import 'package:biit_parent_appointment_system/Models/HistoryModel.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:http/http.dart' as http;

import 'Feedback.dart';

class History extends StatefulWidget {
  List<HistoryModel> history;
  History({Key? key, required this.history}) : super(key: key);

  @override
  State<History> createState() => _HistoryState();
}

class _HistoryState extends State<History> {
//==== API =================

  //=== END API ==============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
      ),
      body: widget.history.isEmpty
          ? const Center(
              child: Text(
                'No Record Exist',
                style: TextStyle(color: Colors.red),
              ),
            )
          : SingleChildScrollView(
              child: Container(
                height: myheight * 0.87,
                margin: EdgeInsets.all(spacewidth),
                child: ListView.builder(
                  itemCount: widget.history.length,
                  itemBuilder: ((context, index) {
                    HistoryModel item = widget.history.elementAt(index);
                    return Column(
                      children: [
                        Row(
                          children: [
                            const Text(
                              'Reg. No:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.regNo)
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'Reason:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.reason)
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'Date:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.date)
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'Start Time:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.startTime)
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'End Time:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.endTime),
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'Refered To:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.referedTo),
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'Suggestion:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.suggestion),
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        //============
                        item.attentive == -1
                            ? Center(
                                child: ElevatedButton(
                                  child: const Text('Feedback Required'),
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                FeedbackScreen(
                                                  hid: item.hid,
                                                )));
                                  },
                                ),
                              )
                            : SizedBox(
                                height: spaceheight * 0.30,
                              ),
                        const Divider(
                          thickness: 2,
                        ),
                      ],
                    );
                  }),
                ),
              ),
            ),
    );
  }
}
