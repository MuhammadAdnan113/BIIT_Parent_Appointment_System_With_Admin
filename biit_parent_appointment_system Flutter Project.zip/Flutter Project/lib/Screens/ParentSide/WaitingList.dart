import 'dart:convert';

import 'package:biit_parent_appointment_system/API/APIHandler.dart';
import 'package:biit_parent_appointment_system/Models/WaitingModel.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

class WaitingList extends StatefulWidget {
  List<WaitingModel> waitinglist;
  WaitingList({super.key, required this.waitinglist});

  @override
  State<WaitingList> createState() => _WaitingListState();
}

class _WaitingListState extends State<WaitingList> {
  //=== Variables =============
  DateTime? pickedDate;

  String formattedDate = '';

  String errormsg = "";
  int statuscode = 0;
  //==== API =========
  // Future<void> rescheduleAppointment(int tsid, String newdate) async {
  //   String url =
  //       '${Variables.baseurl}/Parent/ReSheduleMeeting?tsid=$tsid&date=$newdate&from=Waiting';
  //   var response = await http.get(Uri.parse(url));
  //   statuscode = response.statusCode;
  //   setState(() {
  //     errormsg = response.body;
  //   });
  // }

  Future<void> acceptMeeting(int id) async {
    String url = '${Variables.baseurl}/Parent/AcceptMeeting?id=$id';
    var response = await http.get(Uri.parse(url));
    statuscode = response.statusCode;
    setState(() {
      statuscode = response.statusCode;
      errormsg = response.body;
    });
  }

  //====================

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Waiting List'),
        centerTitle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(25),
              bottomLeft: Radius.circular(25)),
        ),
        elevation: 0.00,
        backgroundColor: Colors.greenAccent[400],
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.only(top: 20, left: 10, right: 10),
          height: myheight * 0.85,
          width: mywidth,
          child: widget.waitinglist.isEmpty
              ? const Center(
                  child: Text(
                    "Please wait OR Reschedule appointment for next Time",
                    style: TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: widget.waitinglist.length,
                  itemBuilder: (context, index) {
                    WaitingModel item = widget.waitinglist.elementAt(index);
                    return widget.waitinglist.isNotEmpty
                        ? Column(
                            children: [
                              Row(
                                children: [
                                  const Text(
                                    'Reg. No:',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(
                                    width: spacewidth,
                                  ),
                                  Text(item.regNo)
                                ],
                              ),
                              SizedBox(
                                height: spaceheight * 0.30,
                              ),
                              Row(
                                children: [
                                  const Text(
                                    'Reason:',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(
                                    width: spacewidth,
                                  ),
                                  Text(item.reason)
                                ],
                              ),
                              SizedBox(
                                height: spaceheight * 0.30,
                              ),
                              Row(
                                children: [
                                  const Text(
                                    'Date:',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(
                                    width: spacewidth,
                                  ),
                                  Text(item.date)
                                ],
                              ),
                              SizedBox(
                                height: spaceheight * 0.30,
                              ),
                              // Row(
                              //   children: [
                              //     ElevatedButton.icon(
                              //         onPressed: () async {
                              //           pickedDate = await showDatePicker(
                              //               context: context,
                              //               initialDate: DateTime.now(),
                              //               firstDate: DateTime.now(),
                              //               //DateTime.now() - not to allow to choose before today.
                              //               lastDate: DateTime(2100));

                              //           if (pickedDate != null) {
                              //             print(
                              //                 pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                              //             formattedDate = DateFormat('d/M/yyyy')
                              //                 .format(pickedDate!);
                              //             print(
                              //                 formattedDate); //formatted date output using intl package =>  2021-03-16
                              //             setState(() {
                              //               //set output date to TextField value.
                              //             });
                              //             if (pickedDate != null) {
                              //               await rescheduleAppointment(
                              //                   item.tsId, formattedDate);
                              //               await getAlertDialog(
                              //                   context, 'Alert', errormsg);
                              //               String id = Variables.getLoginID;
                              //               if (statuscode == 200) {
                              //                 widget.waitinglist.remove(item);
                              //                 setState(() {});
                              //               }
                              //             } else {
                              //               getAlertDialog(context, 'Date Required',
                              //                   "Please Select Valid Date");
                              //             }
                              //           }
                              //         },
                              //         icon: const Icon(Icons.calendar_month),
                              //         label: const Text('Reshedule'))
                              //   ],
                              // ),
                              // SizedBox(
                              //   height: spaceheight * 0.30,
                              // ),
                              item.status == "Calling"
                                  ? Row(
                                      children: [
                                        const Text(
                                          "Admin is Calling to meet them ",
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        ElevatedButton.icon(
                                            onPressed: () async {
                                              await acceptMeeting(item.id);
                                              await getAlertDialog(
                                                  context, "Alert", errormsg);
                                              if (statuscode == 200) {
                                                widget.waitinglist.remove(item);
                                                setState(() {});
                                              }
                                            },
                                            icon: const Icon(Icons.check_sharp),
                                            label: const Text("OK"))
                                      ],
                                    )
                                  : const Text(
                                      "Please wait Admin person will call for Appointment",
                                      style: TextStyle(
                                        color: Colors.red,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                              const Divider(
                                thickness: 2,
                              ),
                            ],
                          )
                        : const Center(
                            child: Text("Waiting List is Empty"),
                          );
                  },
                ),
        ),
      ),
    );
  }
}
