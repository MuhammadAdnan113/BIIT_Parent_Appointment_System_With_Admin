import 'package:biit_parent_appointment_system/Models/HistoryModel.dart';
import 'package:biit_parent_appointment_system/Screens/ParentSide/Parent_Dashboard.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:http/http.dart' as http;

class FeedbackScreen extends StatefulWidget {
  int hid;
  FeedbackScreen({super.key, required this.hid});

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  TextEditingController _suggestion = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  double attentiveRating = 0;
  double politeRating = 0;
  double rudnessRating = 0;
  bool isChecked = false;
  List<Map> behaviourList = [
    {'title': 'Attentive', 'value': false},
    {'title': 'polite', 'value': false},
    {'title': 'rudness', 'value': false},
    {'title': 'Lack of focus', 'value': false},
    {'title': 'Not being mentally present', 'value': false},
  ];

  String selectedbehaviour = "";

//========= API ==============
  String errormsg = '';
  bool changes = false;
  Future<void> saveFeedback(int hid, double attentive, double polite,
      double rudness, String suggestion) async {
    String url =
        '${Variables.baseurl}/Parent/Feedback?hid=$hid&attentive=$attentive&polite=$polite&rudness=$rudness&suggestion=$suggestion';
    print(url);
    var response = await http.get(Uri.parse(url));
    print(response.body);
    if (response.statusCode == 200) {
      setState(() {
        changes = true;
        errormsg = response.body;
      });
    } else {
      getAlertDialog(context, 'Alert', response.body);
    }
  }

  //======== End API ===========

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.blue;
      }
      return Colors.red;
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Feedback'),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: mywidth,
          height: myheight * 0.864,
          margin: const EdgeInsets.only(top: 9),
          child: Column(
            children: [
              const Center(
                child: Text(
                  'Feedback Required for Improvement',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
              ),
              SizedBox(
                height: spaceheight,
              ),
              const Center(
                child: Text(
                  'How was Behaviour?',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
              ),
              SizedBox(
                height: myheight * 0.30,
                width: mywidth,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        const SizedBox(
                            child: Text(
                          'Attentive',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 17),
                        )),
                        RatingBar.builder(
                          initialRating: 0,
                          minRating: 0,
                          allowHalfRating: false,
                          unratedColor: Colors.grey,
                          itemCount: 5,
                          itemSize: 50.0,
                          itemPadding:
                              const EdgeInsets.symmetric(horizontal: 4.0),
                          updateOnDrag: true,
                          itemBuilder: (context, index) => const Icon(
                            Icons.star,
                            color: Colors.amber,
                          ),
                          onRatingUpdate: (ratingvalue) {
                            setState(() {
                              attentiveRating = ratingvalue;
                            });
                          },
                        ),
                      ],
                    ),
                    SizedBox(
                      height: spaceheight,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        const SizedBox(
                            child: Text(
                          'Polite',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 17),
                        )),
                        RatingBar.builder(
                          initialRating: 0,
                          minRating: 0,
                          unratedColor: Colors.grey,
                          itemCount: 5,
                          itemSize: 50.0,
                          itemPadding:
                              const EdgeInsets.symmetric(horizontal: 4.0),
                          updateOnDrag: true,
                          itemBuilder: (context, index) => const Icon(
                            Icons.star,
                            color: Colors.amber,
                          ),
                          onRatingUpdate: (ratingvalue) {
                            setState(() {
                              politeRating = ratingvalue;
                            });
                          },
                        ),
                      ],
                    ),
                    SizedBox(
                      height: spaceheight,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        const SizedBox(
                            child: Text(
                          'Rudness',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 17),
                        )),
                        RatingBar.builder(
                          initialRating: 0,
                          minRating: 0,
                          unratedColor: Colors.grey,
                          itemCount: 5,
                          itemSize: 50.0,
                          itemPadding:
                              const EdgeInsets.symmetric(horizontal: 4.0),
                          updateOnDrag: true,
                          itemBuilder: (context, index) => const Icon(
                            Icons.star,
                            color: Colors.amber,
                          ),
                          onRatingUpdate: (ratingvalue) {
                            setState(() {
                              rudnessRating = ratingvalue;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: spaceheight,
              ),
              const Center(
                child: Text(
                  'Your Suggestions',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
              ),
              SingleChildScrollView(
                child: SizedBox(
                  width: mywidth - 20,
                  child: Form(
                    key: _formKey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: TextFormField(
                      controller: _suggestion,
                      validator: MultiValidator([
                        RequiredValidator(errorText: 'Suggestion is required')
                      ]),
                      style: const TextStyle(fontSize: 20.0),
                      maxLength: 70,
                      decoration:
                          const InputDecoration(labelText: 'Enter Suggestion'),
                      keyboardType: TextInputType.multiline,
                      minLines: 1, // <-- SEE HERE
                      maxLines: 3, // <-- SEE HERE
                    ),
                  ),
                ),
              ),
              Center(
                child: ElevatedButton.icon(
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        await saveFeedback(widget.hid, attentiveRating,
                            politeRating, rudnessRating, _suggestion.text);
                        if (changes) {
                          await getAlertDialog(context, 'Alert', errormsg);
                          Navigator.of(context).pop();
                          Navigator.of(context).pop();
                        }
                      } else {
                        getAlertDialog(
                            context, 'Alert', 'Suggestion is required');
                      }
                    },
                    icon: const Icon(Icons.save),
                    label: const Text('Save')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
