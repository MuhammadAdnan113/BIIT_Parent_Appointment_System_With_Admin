import 'dart:convert';

import 'package:biit_parent_appointment_system/API/APIHandler.dart';
import 'package:biit_parent_appointment_system/Models/HistoryModel.dart';
import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Models/StudentModel.dart';
import 'package:biit_parent_appointment_system/Models/WaitingModel.dart';
import 'package:biit_parent_appointment_system/Screens/ParentSide/History.dart';
import 'package:biit_parent_appointment_system/Screens/ParentSide/Parent_Appointment.dart';
import 'package:biit_parent_appointment_system/Screens/ParentSide/WaitingList.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Parent_Notification.dart';

class ParentDasgboard extends StatefulWidget {
  int notification;
  UserData user;
  ParentDasgboard({Key? key, required this.notification, required this.user})
      : super(key: key);

  @override
  State<ParentDasgboard> createState() => _ParentDasgboardState();
}

class _ParentDasgboardState extends State<ParentDasgboard> {
//=====API Variables=====

  List<NotificationModel> notifications = [];
  bool success = false;
  String errormsg = '';

  //========= API ========================
  Future<void> getNotification(String pcnic) async {
    String url = '${Variables.baseurl}/Parent/GetNotification?pcnic=$pcnic';
    print(url);
    var response = await http.get(Uri.parse(url));
    print(response.body);
    if (response.statusCode == 200) {
      print('successfully called ');
      print(response.body);
      print('Decoding ');
      Iterable listt = json.decode(response.body);
      notifications = listt.map((e) => NotificationModel.fromJson(e)).toList();
      setState(() {
        success = true;
      });
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }
  //========================

  List<StudentModel> students = [];
  bool ssuccess = false;
  String serrormsg = '';

  Future<void> getStudent(String pcnic) async {
    String url = '${Variables.baseurl}/Parent/GetStudent?pid=$pcnic';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      students = listt.map((e) => StudentModel.fromJson(e)).toList();
      setState(() {
        ssuccess = true;
      });
    } else {
      setState(() {
        serrormsg = response.body;
      });
    }
  }

// Issues List=======
  List<String> issuesList = [];
  Future<void> getIssuesList() async {
    String url = '${Variables.baseurl}/Parent/GetIssueList';
    var response = await http.get(Uri.parse(url));
    print(response.body);
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      issuesList = listt.map((e) => e.toString()).toList();
      setState(() {
        ssuccess = true;
      });
    } else {
      setState(() {
        serrormsg = response.body;
      });
    }
  }

  //============
  List<HistoryModel> history = [];

  Future<void> apiGetHistory(String id) async {
    String url = '${Variables.baseurl}/Parent/GetHistory?id=$id';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      history = listt.map((e) => HistoryModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  //==================
  List<TimeSlot> timelist = [];
  Future<void> apiGetTimeSlot(String date) async {
    String url = '${Variables.baseurl}/Parent/GetTimeSlot?date=$date';
    print(url);
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      timelist = listt.map((e) => TimeSlot.fromMap(e)).toList();
      timelist = Variables.removeDuplicateTimeslot(timelist);
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  //==================
  List<WaitingModel> waitinglist = [];
  Future<void> apiGetWaitingList(String id) async {
    String url = '${Variables.baseurl}/Parent/GetWaitingList?id=$id';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      waitinglist = listt.map((e) => WaitingModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }
  //=== API ========================

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return WillPopScope(
      onWillPop: () => showLogOutDialog(context),
      child: Scaffold(
        appBar: AppBar(
          title: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Welcome '),
            Text(
              widget.user.username,
              style: const TextStyle(
                  fontSize: 22.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
            )
          ]),
          centerTitle: true,
          titleSpacing: 00.0,
          toolbarHeight: 60.2,
          toolbarOpacity: 0.8,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(25),
                bottomLeft: Radius.circular(25)),
          ),
          elevation: 0.00,
          backgroundColor: Colors.greenAccent[400],
          actions: [
            IconButton(
              onPressed: () async {
                await getcountNotification('Parent', widget.user.cnic);
                if (getResponse.statusCode == 200) {
                  widget.notification = int.parse(response.body);
                  setState(() {});
                }
              },
              icon: const Icon(Icons.refresh),
            ),
            Stack(
              children: [
                IconButton(
                    onPressed: () async {
                      await getNotification(widget.user.cnic);
                      if (success) {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (cont) => ParentNotification(
                                notification: notifications)));
                      } else {
                        getAlertDialog(context, 'Alert', errormsg);
                      }
                    },
                    icon: const Icon(
                      Icons.notifications,
                      size: 35,
                    )),
                Positioned(
                  left: 22,
                  bottom: 27,
                  child: Text(
                    '${widget.notification}',
                    style: const TextStyle(
                      color: Colors.red,
                    ),
                  ),
                  // IconButton(
                  //   icon: const Icon(Icons.digit, size: 20),
                  //   onPressed: () {},
                  // ),
                ),
              ],
            ),
            const SizedBox(
              width: 10,
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Container(
            alignment: Alignment.center,
            margin: EdgeInsets.only(top: mywidth * 0.01),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                SizedBox(
                  height: spaceheight - 6,
                ),
                //=======================
                getCardWithImage(
                  myheight,
                  mywidth,
                  "Set Appointment",
                  'assets/images/meeting1.png',
                  () async {
                    String formattedDate =
                        Variables.formatter.format(Variables.nowDate);
                    await getStudent(widget.user.cnic);
                    await apiGetTimeSlot(formattedDate);
                    await getIssuesList();
                    List<String> reg = [];
                    for (int i = 0; i < students.length; i++) {
                      String s = students[i].regNo!;
                      reg.add(s);
                    }
                    if (ssuccess && reg.isNotEmpty) {
                      if (issuesList.isEmpty) {
                        issuesList = [
                          'Short Attendance',
                          'Low CGPA',
                          'Fee Issue',
                          'Project Issue'
                        ];
                      }
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (cont) => ParentAppointment(
                                reglist: reg,
                                timelist: timelist,
                                issues: issuesList,
                                mid: -1,
                              )));
                    } else {
                      getAlertDialog(context, 'Alert', serrormsg);
                    }
                  },
                ),
                SizedBox(
                  height: spaceheight,
                ),
                getCardWithImage(
                  myheight,
                  mywidth,
                  "Waiting List",
                  'assets/images/waiting_list.png',
                  () async {
                    await apiGetWaitingList(widget.user.cnic);
                    if (waitinglist.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => WaitingList(
                                waitinglist: waitinglist,
                              )));
                    } else {
                      getAlertDialog(context, 'Alert', errormsg);
                    }
                  },
                ),
                SizedBox(
                  height: spaceheight,
                ),
                getCardWithImage(
                  myheight,
                  mywidth,
                  "History",
                  'assets/images/history.png',
                  () async {
                    await apiGetHistory(widget.user.cnic);
                    if (history.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => History(
                                history: history,
                              )));
                    } else {
                      getAlertDialog(context, 'Alert', errormsg);
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
