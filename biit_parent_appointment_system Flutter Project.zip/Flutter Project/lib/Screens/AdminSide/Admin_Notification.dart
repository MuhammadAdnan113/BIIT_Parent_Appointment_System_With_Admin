import 'dart:convert';

import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/Refer_Appointment.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AdminNotification extends StatefulWidget {
  List<NotificationModel> notification;
  AdminNotification({Key? key, required this.notification}) : super(key: key);

  @override
  State<AdminNotification> createState() => AdminNotificationState();
}

class AdminNotificationState extends State<AdminNotification> {
  final List<String> _referlist = [
    'Datacell',
    'Project Committee',
    'Accountant',
    'Director',
    'Deputy Director'
  ];
  String _refer = 'Datacell';
  NotificationModel? appointment;

//======= API =============

  List<TimeSlot> timelist = [];
  String errormsg = '';
  Future<void> apiGetTimeSlotByRole(String role) async {
    String url = '${Variables.baseurl}/admin/GetTimeSlotRole?role=$role';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      timelist = listt.map((e) => TimeSlot.fromMap(e)).toList();
      setState(() {});
    } else {
      setState(() {
        timelist = [];
        errormsg = response.body;
      });
    }
  }

//======= End API ===============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Notification'),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: myheight * 0.87,
          margin: EdgeInsets.all(spacewidth),
          child: ListView.builder(
            itemCount: widget.notification.length,
            itemBuilder: ((context, index) {
              NotificationModel item = widget.notification.elementAt(index);
              return Column(
                children: [
                  Row(
                    children: [
                      const Text(
                        'Reg. No:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).regNo)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Reason:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).reason)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Date:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).date)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Start Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).startTime)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'End Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).endTime),
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  item.status == "Reschedualed"
                      ? const Text(
                          "Appointment Reschedualed so waiting for Parent Response",
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.bold),
                        )
                      : item.status == "Request"
                          ? const Text(
                              "Requested for Appointment",
                              style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold),
                            )
                          : item.status == "Wait"
                              ? const Text(
                                  "Requested to Wait",
                                  style: TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold),
                                )
                              : Row(
                                  children: [
                                    const Text(
                                      'Refer to:',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      width: spacewidth,
                                    ),
                                    DropdownButton(
                                        // Initial Value
                                        value: _refer,
                                        // Down Arrow Icon
                                        icon: const Icon(
                                            Icons.keyboard_arrow_down),
                                        // Array list of items
                                        items: _referlist.map((String items) {
                                          return DropdownMenuItem(
                                            value: items,
                                            child: Text(items),
                                          );
                                        }).toList(),
                                        // After selecting the desired option,it will
                                        // change button value to selected value
                                        onChanged: (String? newValue) async {
                                          setState(() {
                                            _refer = newValue!;
                                          });
                                          await apiGetTimeSlotByRole(_refer);
                                          if (_refer == 'Datacell') {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReferTo(
                                                          title: 'Datacell',
                                                          request: item,
                                                          timeslot: timelist,
                                                        )));
                                          } else if (_refer ==
                                              'Project Committee') {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReferTo(
                                                          title:
                                                              'Project Committee',
                                                          request: item,
                                                          timeslot: timelist,
                                                        )));
                                          } else if (_refer == 'Accountant') {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReferTo(
                                                          title: 'Accountant',
                                                          request: item,
                                                          timeslot: timelist,
                                                        )));
                                          } else if (_refer == 'Director') {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReferTo(
                                                          title: 'Director',
                                                          request: item,
                                                          timeslot: timelist,
                                                        )));
                                          } else if (_refer ==
                                              'Deputy Director') {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReferTo(
                                                          title:
                                                              'Deputy Director',
                                                          request: item,
                                                          timeslot: timelist,
                                                        )));
                                          }
                                        }),
                                  ],
                                ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  const Divider(
                    thickness: 2,
                  ),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
