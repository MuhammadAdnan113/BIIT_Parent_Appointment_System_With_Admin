import 'dart:convert';

import 'package:biit_parent_appointment_system/Models/AttendanceModel.dart';
import 'package:biit_parent_appointment_system/Models/CGPAModel.dart';
import 'package:biit_parent_appointment_system/Models/DisciplenaryModel.dart';
import 'package:biit_parent_appointment_system/Models/FailedSubjectModel.dart';
import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/Disciplinary.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/Failed_Subjects.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/IndividualMeeting.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/Low_CGPA.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/Short_Attendance.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AdminSetAppointment extends StatefulWidget {
  final UserData user;
  const AdminSetAppointment({Key? key, required this.user}) : super(key: key);

  @override
  State<AdminSetAppointment> createState() => _AdminSetAppointmentState();
}

class _AdminSetAppointmentState extends State<AdminSetAppointment> {
//=====API Variables=====
  List<NotificationModel> notifications = [];
  bool success = false;
  String errormsg = '';

  //========= API ========================
  List<TimeSlot> timelist = [];
  Future<void> apiGetTimeSlot() async {
    String url =
        '${Variables.baseurl}/admin/GetTimeSlot?adminid=${widget.user.cnic}';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      timelist = listt.map((e) => TimeSlot.fromMap(e)).toList();
      timelist = Variables.removeDuplicateTimeslot(timelist);
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//==================================

  List<NotificationModel> history = [];

  Future<void> apiGetCompletedMeetings(String admin) async {
    String url = '${Variables.baseurl}/Admin/GetCompletedMeeting?admin=$admin';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      history = listt.map((e) => NotificationModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  //==========================
  List<CGPAModel> lowCGPA = [];
  Future<void> apiGetLowCGPA() async {
    String url = '${Variables.baseurl}/admin/GetLowCGPAStudents';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      lowCGPA = listt.map((e) => CGPAModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//===============================
  List<AttendanceModel> shortAttendance = [];
  Future<void> apiGetShortAttendance() async {
    String url = '${Variables.baseurl}/admin/GetShortAttendance';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      shortAttendance = listt.map((e) => AttendanceModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//==========================
  List<DisciplinaryModel> disciplenary = [];
  Future<void> apiGetDisciplenary() async {
    String url = '${Variables.baseurl}/admin/GetDisciplenary';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      disciplenary = listt.map((e) => DisciplinaryModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//===============================

//==========================
  List<FailedSubjectModel> failedSubjects = [];
  Future<void> apiGetFailedSubjects() async {
    String url = '${Variables.baseurl}/admin/GetFailedSubjects';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      failedSubjects =
          listt.map((e) => FailedSubjectModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//===============================

  //====== API ===============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Set Appointments'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.center,
          margin: EdgeInsets.only(top: mywidth * 0.08),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {
                  await apiGetShortAttendance();
                  if (shortAttendance.isNotEmpty) {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) =>
                            ShortAttendance(students: shortAttendance)));
                  } else {
                    getAlertDialog(context, 'Alert', errormsg);
                  }
                },
                style:
                    ElevatedButton.styleFrom(minimumSize: const Size(200, 37)),
                child: const Text('Short Attendance'),
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {
                  await apiGetLowCGPA();
                  if (lowCGPA.isNotEmpty) {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => LowCGPA(students: lowCGPA)));
                  } else {
                    getAlertDialog(context, 'Alert', errormsg);
                  }
                },
                style:
                    ElevatedButton.styleFrom(minimumSize: const Size(200, 37)),
                child: const Text('Low CGPA'),
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {
                  await apiGetDisciplenary();
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) =>
                          Disciplinary(disciplinary: disciplenary)));
                },
                style:
                    ElevatedButton.styleFrom(minimumSize: const Size(200, 37)),
                child: const Text('Disciplinary'),
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {
                  await apiGetFailedSubjects();
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) =>
                          FailedSubjects(failed: failedSubjects)));
                },
                style:
                    ElevatedButton.styleFrom(minimumSize: const Size(200, 37)),
                child: const Text('Failed Subjects'),
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {
                  await apiGetTimeSlot();
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => IndividualMeeting(
                            timelist: timelist,
                          )));
                },
                style:
                    ElevatedButton.styleFrom(minimumSize: const Size(200, 37)),
                child: const Text('Individual Meeting'),
              ),
              const Divider(
                thickness: 2,
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {},
                style:
                    ElevatedButton.styleFrom(minimumSize: const Size(200, 37)),
                child: const Text('Call Parent'),
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {},
                style:
                    ElevatedButton.styleFrom(minimumSize: const Size(200, 37)),
                child: const Text('Call Student'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
