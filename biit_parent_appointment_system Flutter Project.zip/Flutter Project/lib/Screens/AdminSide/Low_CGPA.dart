import 'package:biit_parent_appointment_system/API/APIHandler.dart';
import 'package:biit_parent_appointment_system/Models/CGPAModel.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class LowCGPA extends StatefulWidget {
  List<CGPAModel> students;
  LowCGPA({Key? key, required this.students}) : super(key: key);

  @override
  State<LowCGPA> createState() => _LowCGPAState();
}

class _LowCGPAState extends State<LowCGPA> {
  DateTime? pickedDate;
  String formattedDate = '';
//=====API Variables=====
  String errormsg = '';
  //========= API ========================
  Future<void> apiSetLowCGPA(String date) async {
    String url = '${Variables.baseurl}/Admin/LowCGPAAppointment?date=$date';
    var response = await http.get(Uri.parse(url));
    print(response.body);
    if (response.statusCode == 200) {
      errormsg = response.body;
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Low CGPA Students List'),
        centerTitle: true,
      ),
      body: Container(
        height: myheight,
        width: mywidth,
        padding: const EdgeInsets.all(3.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                const Text(
                  'RegNo',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: spacewidth * 4,
                ),
                const Text(
                  'Class',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: spacewidth * 4,
                ),
                const Text(
                  'CGPA',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
            RefreshIndicator(
              onRefresh: () async {
                await apiGetLowCGPA();
                if (getResponse.statusCode == 200) {
                  widget.students = getAPIData;
                }
              },
              child: SizedBox(
                height: myheight * 0.75,
                width: mywidth,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: widget.students.length,
                  itemBuilder: ((context, index) {
                    CGPAModel item = widget.students.elementAt(index);
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text(item.regNo),
                        Text('${item.class1}-${item.semester}${item.section}'),
                        Text('${item.cgpa}'),
                      ],
                    );
                  }),
                ),
              ),
            ),
            SizedBox(
              height: spaceheight,
            ),
            ElevatedButton(
                onPressed: widget.students.isEmpty
                    ? null
                    : () async {
                        pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime.now(),
                            //DateTime.now() - not to allow to choose before today.
                            lastDate: DateTime(2100));

                        if (pickedDate != null) {
                          print(
                              pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                          formattedDate =
                              DateFormat('d/M/yyyy').format(pickedDate!);
                          print(
                              formattedDate); //formatted date output using intl package =>  2021-03-16
                          setState(() {
                            //set output date to TextField value.
                          });
                          if (pickedDate != null) {
                            await apiSetLowCGPA(formattedDate);
                            await getAlertDialog(context, 'Alert', errormsg);
                          } else {
                            getAlertDialog(context, 'Date Required',
                                "Please Select Valid Date");
                          }
                        }
                      },
                child: const Text('Set Appointment')),
          ],
        ),
      ),
    );
  }
}
