import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

class IndividualMeeting extends StatefulWidget {
  List<TimeSlot> timelist;
  IndividualMeeting({super.key, required this.timelist});

  @override
  State<IndividualMeeting> createState() => _IndividualMeetingState();
}

class _IndividualMeetingState extends State<IndividualMeeting> {
  TextEditingController _regno = TextEditingController(text: '');
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final List<String> issuesList = [
    'Short Attendance',
    'Low CGPA',
    'Fee Issue',
    'Project Issue'
  ];
  String _issue = 'Short Attendance';

  DateTime? pickedDate;
  String formattedDate = Variables.systemDate;

  bool changes = false;
  Future<void> apiCustomMeeting(String regno, String adminid, String date,
      int tsid, String reason) async {
    String url =
        '${Variables.baseurl}/admin/CustomMeeting?regno=$regno&adminid=$adminid&date=$date&tsid=$tsid&reason=$reason';
    print(url);
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      await getAlertDialog(context, 'Alert', response.body);
      setState(() {
        changes = true;
      });
    } else {
      await getAlertDialog(context, 'Alert', response.body);
      setState(() {
        changes = false;
      });
    }
  }

  // initializing Values
  @override
  void initState() {
    _issue = issuesList[0];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Set Individual Appointment"),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.only(left: 10, right: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: spaceheight,
              ),
              Form(
                key: _formKey,
                child: getTextFormField(
                  hintText: 'Enter Reg No',
                  controller: _regno,
                  lbltext: 'Student Reg No',
                  maxlength: 14,
                  inputType: TextInputType.emailAddress,
                  suffixIcon: const Icon(
                    Icons.person,
                    color: Color.fromARGB(255, 237, 143, 3),
                  ),
                  validator: MultiValidator(
                    [
                      RequiredValidator(errorText: 'Field cannot be empty'),
                      PatternValidator(
                          "[\\d]{4}[-]{1}[A|a]{1}[rid]+[-][\\d]{4}",
                          errorText: 'Enter Valid Reg No'),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: spaceheight,
              ),
              Row(
                children: [
                  const Text('Select Issue'),
                  SizedBox(
                    width: spacewidth,
                  ),
                  DropdownButton(
                      // Initial Value
                      value: _issue,
                      // Down Arrow Icon
                      icon: const Icon(Icons.keyboard_arrow_down),
                      // Array list of items
                      items: issuesList.map((String items) {
                        return DropdownMenuItem(
                          value: items,
                          child: Text(
                            items,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        );
                      }).toList(),
                      // After selecting the desired option,it will
                      // change button value to selected value
                      onChanged: (String? newValue) {
                        setState(() {
                          _issue = newValue!;
                        });
                      }),
                ],
              ),
              SizedBox(
                height: spaceheight,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Select Appointment Date  '),
                  ElevatedButton.icon(
                    onPressed: () async {
                      pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime.now(),
                          //DateTime.now() - not to allow to choose before today.
                          lastDate: DateTime(2100));

                      if (pickedDate != null) {
                        print(
                            pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                        formattedDate =
                            DateFormat('d/M/yyyy').format(pickedDate!);
                        print(
                            formattedDate); //formatted date output using intl package =>  2021-03-16
                        setState(() {
                          //set output date to TextField value.
                        });
                        if (pickedDate != null) {
                          // Function here
                          //await apiGetTimeSlot(formattedDate);
                        }
                      }
                    },
                    icon: const Icon(Icons.calendar_month_sharp),
                    label: Text(formattedDate),
                  ),
                ],
              ),
              SizedBox(
                height: spaceheight,
              ),
              const Center(
                child: Text(
                  "Available Slots",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: spaceheight,
              ),
              widget.timelist.isNotEmpty
                  ? SizedBox(
                      height: myheight * 0.5,
                      width: mywidth,
                      child: GridView.builder(
                        shrinkWrap: true,
                        gridDelegate:
                            const SliverGridDelegateWithMaxCrossAxisExtent(
                                maxCrossAxisExtent: 200,
                                childAspectRatio: 4 / 2,
                                crossAxisSpacing: 20,
                                mainAxisSpacing: 2),
                        itemCount: widget.timelist.length,
                        itemBuilder: (context, index) {
                          TimeSlot item = widget.timelist.elementAt(index);
                          return SizedBox(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    ElevatedButton.icon(
                                        onPressed: () async {
                                          if (_formKey.currentState!
                                              .validate()) {
                                            if (formattedDate ==
                                                Variables.systemDate) {}
                                            await apiCustomMeeting(
                                                _regno.text,
                                                Variables.getLoginID,
                                                formattedDate,
                                                item.tsid,
                                                _issue);
                                            if (changes) {
                                              widget.timelist.remove(item);
                                              setState(() {});
                                            }
                                          }
                                        },
                                        icon: const Icon(Icons.check_outlined),
                                        label: Text(
                                            "${item.startTime}-${item.endTime}")),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    )
                  : const Text(
                      'Today No Slot Available for Appointment',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.redAccent),
                    ),
              SizedBox(
                height: spaceheight,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
