import 'dart:convert';
import 'dart:ui';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;

import '../../Models/Models.dart';
import '../../Variables/Variables.dart';

class Availability extends StatefulWidget {
  final UserData user;
  List<TimeSlot> timelist;
  Availability({Key? key, required this.user, required this.timelist})
      : super(key: key);

  @override
  State<Availability> createState() => _AvailabilityState();
}

class _AvailabilityState extends State<Availability> {
//====== End Connectivity =======================

  bool firstcheck = false;

  //=====API Variables=====
  String errormsg = '';
  bool changes = false;
  //========= API ========================
  Future<void> updateAvailability(int tsid, bool avb) async {
    String url =
        '${Variables.baseurl}/Admin/UpdateAvailability?tsid=$tsid&avb=$avb';
    print(url);
    var response = await http.get(Uri.parse(url));
    print(response.body);
    if (response.statusCode == 200) {
      setState(() {
        changes = true;
        errormsg = response.body;
      });
    } else if (response.statusCode == 304) {
      await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (cont) {
            return AlertDialog(
              title: const Text("Confirmation?"),
              content:
                  const Text("want to readjust appointment with other admin?"),
              actions: [
                TextButton(
                  onPressed: () async {
                    await adjustOneAppointment(tsid);
                    Navigator.of(context).pop();
                    setState(() {
                      changes = true;
                    });
                  },
                  child: const Text("Yes"),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    setState(() {
                      changes = false;
                    });
                  },
                  child: const Text("No"),
                ),
              ],
            );
          });
    } else {
      getAlertDialog(context, 'Alert', response.body);
      setState(() {
        changes = false;
      });
    }
  }

  Future<void> adjustOneAppointment(int tsid) async {
    String url = '${Variables.baseurl}/Admin/AdjustOneAppointment?tsid=$tsid';
    print(url);
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      getAlertDialog(context, 'Alert', response.body);
      setState(() {
        changes = true;
        errormsg = response.body;
      });
    } else {
      getAlertDialog(context, 'Alert', response.body);
      setState(() {
        changes = false;
      });
    }
  }

  //====== API ===============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Schedule'),
        centerTitle: true,
      ),
      body: Container(
        height: myheight - 10,
        width: mywidth,
        padding: const EdgeInsets.all(3.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Table(
                children: const [
                  TableRow(children: [
                    Text(
                      'Time',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 19,
                      ),
                    ),
                    Text(
                      'Mon',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 19,
                      ),
                    ),
                    Text(
                      'Tue',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 19,
                      ),
                    ),
                    Text(
                      'Wed',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 19,
                      ),
                    ),
                    Text(
                      'Thu',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 19,
                      ),
                    ),
                    Text(
                      'Fri',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 19,
                      ),
                    ),
                  ]),
                ],
              ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.spaceAround,
              //   children: const [
              //     Text(
              //       'Time',
              //       style: TextStyle(
              //         color: Colors.black,
              //         fontWeight: FontWeight.bold,
              //       ),
              //     ),
              //     Text(
              //       'Mon',
              //       style: TextStyle(
              //         color: Colors.black,
              //         fontWeight: FontWeight.bold,
              //       ),
              //     ),
              //     Text(
              //       'Tue',
              //       style: TextStyle(
              //         color: Colors.black,
              //         fontWeight: FontWeight.bold,
              //       ),
              //     ),
              //     Text(
              //       'Wed',
              //       style: TextStyle(
              //         color: Colors.black,
              //         fontWeight: FontWeight.bold,
              //       ),
              //     ),
              //     Text(
              //       'Thu',
              //       style: TextStyle(
              //         color: Colors.black,
              //         fontWeight: FontWeight.bold,
              //       ),
              //     ),
              //     Text(
              //       'Fri',
              //       style: TextStyle(
              //         color: Colors.black,
              //         fontWeight: FontWeight.bold,
              //       ),
              //     ),
              //   ],
              // ),
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                defaultColumnWidth: const FlexColumnWidth(3),
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[0].startTime}-${widget.timelist[0].endTime}'),
                    Checkbox(
                        value: widget.timelist[0].availability ?? false,
                        onChanged: widget.timelist[0].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[0].tsid, value!);
                                if (changes) {
                                  widget.timelist[0].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[1].availability ?? false,
                        onChanged: widget.timelist[1].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[1].tsid, value!);
                                if (changes) {
                                  widget.timelist[1].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[2].availability ?? false,
                        onChanged: widget.timelist[2].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[2].tsid, value!);
                                if (changes) {
                                  widget.timelist[2].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[3].availability ?? false,
                        onChanged: widget.timelist[3].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[3].tsid, value!);
                                if (changes) {
                                  widget.timelist[3].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[4].availability ?? false,
                        onChanged: widget.timelist[4].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[4].tsid, value!);
                                if (changes) {
                                  widget.timelist[4].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[5].startTime}-${widget.timelist[5].endTime}'),
                    Checkbox(
                        value: widget.timelist[5].availability ?? false,
                        onChanged: widget.timelist[5].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[5].tsid, value!);
                                if (changes) {
                                  widget.timelist[5].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[6].availability ?? false,
                        onChanged: widget.timelist[6].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[6].tsid, value!);
                                if (changes) {
                                  widget.timelist[6].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[7].availability ?? false,
                        onChanged: widget.timelist[7].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[7].tsid, value!);
                                if (changes) {
                                  widget.timelist[7].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[8].availability ?? false,
                        onChanged: widget.timelist[8].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[8].tsid, value!);
                                if (changes) {
                                  widget.timelist[8].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[9].availability ?? false,
                        onChanged: widget.timelist[9].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[9].tsid, value!);
                                if (changes) {
                                  widget.timelist[9].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //==============
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[10].startTime}-${widget.timelist[10].endTime}'),
                    Checkbox(
                        value: widget.timelist[10].availability ?? false,
                        onChanged: widget.timelist[10].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[10].tsid, value!);
                                if (changes) {
                                  widget.timelist[10].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[11].availability ?? false,
                        onChanged: widget.timelist[11].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[11].tsid, value!);
                                if (changes) {
                                  widget.timelist[11].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[12].availability ?? false,
                        onChanged: widget.timelist[12].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[12].tsid, value!);
                                if (changes) {
                                  widget.timelist[12].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[13].availability ?? false,
                        onChanged: widget.timelist[13].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[13].tsid, value!);
                                if (changes) {
                                  widget.timelist[13].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[14].availability ?? false,
                        onChanged: widget.timelist[14].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[14].tsid, value!);
                                if (changes) {
                                  widget.timelist[14].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //==================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[15].startTime}-${widget.timelist[15].endTime}'),
                    Checkbox(
                        value: widget.timelist[15].availability ?? false,
                        onChanged: widget.timelist[15].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[15].tsid, value!);
                                if (changes) {
                                  widget.timelist[15].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[16].availability ?? false,
                        onChanged: widget.timelist[16].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[16].tsid, value!);
                                if (changes) {
                                  widget.timelist[16].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[17].availability ?? false,
                        onChanged: widget.timelist[17].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[17].tsid, value!);
                                if (changes) {
                                  widget.timelist[17].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[18].availability ?? false,
                        onChanged: widget.timelist[18].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[18].tsid, value!);
                                if (changes) {
                                  widget.timelist[18].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[19].availability ?? false,
                        onChanged: widget.timelist[19].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[19].tsid, value!);
                                if (changes) {
                                  widget.timelist[19].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //====================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[20].startTime}-${widget.timelist[20].endTime}'),
                    Checkbox(
                        value: widget.timelist[20].availability ?? false,
                        onChanged: widget.timelist[20].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[20].tsid, value!);
                                if (changes) {
                                  widget.timelist[20].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[21].availability ?? false,
                        onChanged: widget.timelist[21].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[21].tsid, value!);
                                if (changes) {
                                  widget.timelist[21].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[22].availability ?? false,
                        onChanged: widget.timelist[22].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[22].tsid, value!);
                                if (changes) {
                                  widget.timelist[22].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[23].availability ?? false,
                        onChanged: widget.timelist[23].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[23].tsid, value!);
                                if (changes) {
                                  widget.timelist[23].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[24].availability ?? false,
                        onChanged: widget.timelist[24].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[24].tsid, value!);
                                if (changes) {
                                  widget.timelist[24].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              //==================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[25].startTime}-${widget.timelist[25].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[25].availability ?? false,
                        onChanged: widget.timelist[25].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[25].tsid, value!);
                                if (changes) {
                                  widget.timelist[25].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[26].availability ?? false,
                        onChanged: widget.timelist[26].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[26].tsid, value!);
                                if (changes) {
                                  widget.timelist[26].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[27].availability ?? false,
                        onChanged: widget.timelist[27].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[27].tsid, value!);
                                if (changes) {
                                  widget.timelist[27].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[28].availability ?? false,
                        onChanged: widget.timelist[28].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[28].tsid, value!);
                                if (changes) {
                                  widget.timelist[28].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[29].availability ?? false,
                        onChanged: widget.timelist[29].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[29].tsid, value!);
                                if (changes) {
                                  widget.timelist[29].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //====================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[30].startTime}-${widget.timelist[30].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[30].availability ?? false,
                        onChanged: widget.timelist[30].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[30].tsid, value!);
                                if (changes) {
                                  widget.timelist[30].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[31].availability ?? false,
                        onChanged: widget.timelist[31].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[31].tsid, value!);
                                if (changes) {
                                  widget.timelist[31].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[32].availability ?? false,
                        onChanged: widget.timelist[32].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[32].tsid, value!);
                                if (changes) {
                                  widget.timelist[32].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[33].availability ?? false,
                        onChanged: widget.timelist[33].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[33].tsid, value!);
                                if (changes) {
                                  widget.timelist[33].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[34].availability ?? false,
                        onChanged: widget.timelist[34].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[34].tsid, value!);
                                if (changes) {
                                  widget.timelist[34].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              //==================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[35].startTime}-${widget.timelist[35].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[35].availability ?? false,
                        onChanged: widget.timelist[35].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[35].tsid, value!);
                                if (changes) {
                                  widget.timelist[35].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[36].availability ?? false,
                        onChanged: widget.timelist[36].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[36].tsid, value!);
                                if (changes) {
                                  widget.timelist[36].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[37].availability ?? false,
                        onChanged: widget.timelist[37].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[37].tsid, value!);
                                if (changes) {
                                  widget.timelist[37].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[38].availability ?? false,
                        onChanged: widget.timelist[38].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[38].tsid, value!);
                                if (changes) {
                                  widget.timelist[38].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[39].availability ?? false,
                        onChanged: widget.timelist[39].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[39].tsid, value!);
                                if (changes) {
                                  widget.timelist[39].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //====================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[40].startTime}-${widget.timelist[40].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[40].availability ?? false,
                        onChanged: widget.timelist[40].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[40].tsid, value!);
                                if (changes) {
                                  widget.timelist[40].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[41].availability ?? false,
                        onChanged: widget.timelist[41].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[41].tsid, value!);
                                if (changes) {
                                  widget.timelist[41].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[42].availability ?? false,
                        onChanged: widget.timelist[42].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[42].tsid, value!);
                                if (changes) {
                                  widget.timelist[42].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[43].availability ?? false,
                        onChanged: widget.timelist[43].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[43].tsid, value!);
                                if (changes) {
                                  widget.timelist[43].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[44].availability ?? false,
                        onChanged: widget.timelist[44].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[44].tsid, value!);
                                if (changes) {
                                  widget.timelist[44].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              //==================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[45].startTime}-${widget.timelist[45].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[45].availability ?? false,
                        onChanged: widget.timelist[45].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[45].tsid, value!);
                                if (changes) {
                                  widget.timelist[45].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[46].availability ?? false,
                        onChanged: widget.timelist[46].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[46].tsid, value!);
                                if (changes) {
                                  widget.timelist[46].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[47].availability ?? false,
                        onChanged: widget.timelist[47].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[47].tsid, value!);
                                if (changes) {
                                  widget.timelist[47].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[48].availability ?? false,
                        onChanged: widget.timelist[48].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[48].tsid, value!);
                                if (changes) {
                                  widget.timelist[48].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[49].availability ?? false,
                        onChanged: widget.timelist[49].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[49].tsid, value!);
                                if (changes) {
                                  widget.timelist[49].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //====================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[50].startTime}-${widget.timelist[50].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[50].availability ?? false,
                        onChanged: widget.timelist[50].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[50].tsid, value!);
                                if (changes) {
                                  widget.timelist[50].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[51].availability ?? false,
                        onChanged: widget.timelist[51].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[51].tsid, value!);
                                if (changes) {
                                  widget.timelist[51].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[52].availability ?? false,
                        onChanged: widget.timelist[52].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[52].tsid, value!);
                                if (changes) {
                                  widget.timelist[52].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[53].availability ?? false,
                        onChanged: widget.timelist[53].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[53].tsid, value!);
                                if (changes) {
                                  widget.timelist[53].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[54].availability ?? false,
                        onChanged: widget.timelist[54].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[54].tsid, value!);
                                if (changes) {
                                  widget.timelist[54].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              //====================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[55].startTime}-${widget.timelist[55].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[55].availability ?? false,
                        onChanged: widget.timelist[55].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[55].tsid, value!);
                                if (changes) {
                                  widget.timelist[55].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[56].availability ?? false,
                        onChanged: widget.timelist[56].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[56].tsid, value!);
                                if (changes) {
                                  widget.timelist[56].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[57].availability ?? false,
                        onChanged: widget.timelist[57].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[57].tsid, value!);
                                if (changes) {
                                  widget.timelist[57].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[58].availability ?? false,
                        onChanged: widget.timelist[58].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[58].tsid, value!);
                                if (changes) {
                                  widget.timelist[58].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[59].availability ?? false,
                        onChanged: widget.timelist[59].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[59].tsid, value!);
                                if (changes) {
                                  widget.timelist[59].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[60].startTime}-${widget.timelist[60].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[60].availability ?? false,
                        onChanged: widget.timelist[60].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[60].tsid, value!);
                                if (changes) {
                                  widget.timelist[60].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[61].availability ?? false,
                        onChanged: widget.timelist[61].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[61].tsid, value!);
                                if (changes) {
                                  widget.timelist[61].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[62].availability ?? false,
                        onChanged: widget.timelist[62].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[62].tsid, value!);
                                if (changes) {
                                  widget.timelist[62].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[63].availability ?? false,
                        onChanged: widget.timelist[63].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[63].tsid, value!);
                                if (changes) {
                                  widget.timelist[63].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[64].availability ?? false,
                        onChanged: widget.timelist[64].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[64].tsid, value!);
                                if (changes) {
                                  widget.timelist[64].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[65].startTime}-${widget.timelist[65].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[65].availability ?? false,
                        onChanged: widget.timelist[65].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[65].tsid, value!);
                                if (changes) {
                                  widget.timelist[65].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[66].availability ?? false,
                        onChanged: widget.timelist[66].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[66].tsid, value!);
                                if (changes) {
                                  widget.timelist[66].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[67].availability ?? false,
                        onChanged: widget.timelist[67].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[67].tsid, value!);
                                if (changes) {
                                  widget.timelist[67].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[68].availability ?? false,
                        onChanged: widget.timelist[68].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[68].tsid, value!);
                                if (changes) {
                                  widget.timelist[68].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[69].availability ?? false,
                        onChanged: widget.timelist[69].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[69].tsid, value!);
                                if (changes) {
                                  widget.timelist[69].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[70].startTime}-${widget.timelist[70].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[70].availability ?? false,
                        onChanged: widget.timelist[70].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[70].tsid, value!);
                                if (changes) {
                                  widget.timelist[70].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[71].availability ?? false,
                        onChanged: widget.timelist[71].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[71].tsid, value!);
                                if (changes) {
                                  widget.timelist[71].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[72].availability ?? false,
                        onChanged: widget.timelist[72].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[72].tsid, value!);
                                if (changes) {
                                  widget.timelist[72].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[73].availability ?? false,
                        onChanged: widget.timelist[73].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[73].tsid, value!);
                                if (changes) {
                                  widget.timelist[73].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[74].availability ?? false,
                        onChanged: widget.timelist[74].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[74].tsid, value!);
                                if (changes) {
                                  widget.timelist[74].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[75].startTime}-${widget.timelist[75].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[75].availability ?? false,
                        onChanged: widget.timelist[75].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[75].tsid, value!);
                                if (changes) {
                                  widget.timelist[75].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[76].availability ?? false,
                        onChanged: widget.timelist[76].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[76].tsid, value!);
                                if (changes) {
                                  widget.timelist[76].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[77].availability ?? false,
                        onChanged: widget.timelist[77].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[77].tsid, value!);
                                if (changes) {
                                  widget.timelist[77].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[78].availability ?? false,
                        onChanged: widget.timelist[78].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[78].tsid, value!);
                                if (changes) {
                                  widget.timelist[78].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[79].availability ?? false,
                        onChanged: widget.timelist[79].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[79].tsid, value!);
                                if (changes) {
                                  widget.timelist[79].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                      '${widget.timelist[80].startTime}-${widget.timelist[80].endTime}',
                      style: const TextStyle(
                        fontSize: 12.7,
                      ),
                    ),
                    Checkbox(
                        value: widget.timelist[80].availability ?? false,
                        onChanged: widget.timelist[80].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[80].tsid, value!);
                                if (changes) {
                                  widget.timelist[80].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[81].availability ?? false,
                        onChanged: widget.timelist[81].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[81].tsid, value!);
                                if (changes) {
                                  widget.timelist[81].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[82].availability ?? false,
                        onChanged: widget.timelist[82].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[82].tsid, value!);
                                if (changes) {
                                  widget.timelist[82].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[83].availability ?? false,
                        onChanged: widget.timelist[83].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[83].tsid, value!);
                                if (changes) {
                                  widget.timelist[83].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[84].availability ?? false,
                        onChanged: widget.timelist[84].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[84].tsid, value!);
                                if (changes) {
                                  widget.timelist[84].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[85].startTime}-${widget.timelist[85].endTime}'),
                    Checkbox(
                        value: widget.timelist[85].availability ?? false,
                        onChanged: widget.timelist[85].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[85].tsid, value!);
                                if (changes) {
                                  widget.timelist[85].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[86].availability ?? false,
                        onChanged: widget.timelist[86].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[86].tsid, value!);
                                if (changes) {
                                  widget.timelist[86].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[87].availability ?? false,
                        onChanged: widget.timelist[87].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[87].tsid, value!);
                                if (changes) {
                                  widget.timelist[87].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[88].availability ?? false,
                        onChanged: widget.timelist[88].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[88].tsid, value!);
                                if (changes) {
                                  widget.timelist[88].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[89].availability ?? false,
                        onChanged: widget.timelist[89].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[89].tsid, value!);
                                if (changes) {
                                  widget.timelist[89].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[90].startTime}-${widget.timelist[90].endTime}'),
                    Checkbox(
                        value: widget.timelist[90].availability ?? false,
                        onChanged: widget.timelist[90].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[90].tsid, value!);
                                if (changes) {
                                  widget.timelist[90].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[91].availability ?? false,
                        onChanged: widget.timelist[91].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[91].tsid, value!);
                                if (changes) {
                                  widget.timelist[91].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[92].availability ?? false,
                        onChanged: widget.timelist[92].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[92].tsid, value!);
                                if (changes) {
                                  widget.timelist[92].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[93].availability ?? false,
                        onChanged: widget.timelist[93].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[93].tsid, value!);
                                if (changes) {
                                  widget.timelist[93].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[94].availability ?? false,
                        onChanged: widget.timelist[94].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[94].tsid, value!);
                                if (changes) {
                                  widget.timelist[94].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[95].startTime}-${widget.timelist[95].endTime}'),
                    Checkbox(
                        value: widget.timelist[95].availability ?? false,
                        onChanged: widget.timelist[95].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[95].tsid, value!);
                                if (changes) {
                                  widget.timelist[95].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[96].availability ?? false,
                        onChanged: widget.timelist[96].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[96].tsid, value!);
                                if (changes) {
                                  widget.timelist[96].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[97].availability ?? false,
                        onChanged: widget.timelist[97].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[97].tsid, value!);
                                if (changes) {
                                  widget.timelist[97].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[98].availability ?? false,
                        onChanged: widget.timelist[98].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[98].tsid, value!);
                                if (changes) {
                                  widget.timelist[98].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[99].availability ?? false,
                        onChanged: widget.timelist[99].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[99].tsid, value!);
                                if (changes) {
                                  widget.timelist[99].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[100].startTime}-${widget.timelist[100].endTime}'),
                    Checkbox(
                        value: widget.timelist[100].availability ?? false,
                        onChanged: widget.timelist[100].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[100].tsid, value!);
                                if (changes) {
                                  widget.timelist[100].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[101].availability ?? false,
                        onChanged: widget.timelist[101].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[101].tsid, value!);
                                if (changes) {
                                  widget.timelist[101].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[102].availability ?? false,
                        onChanged: widget.timelist[102].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[102].tsid, value!);
                                if (changes) {
                                  widget.timelist[102].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[103].availability ?? false,
                        onChanged: widget.timelist[103].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[103].tsid, value!);
                                if (changes) {
                                  widget.timelist[103].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[104].availability ?? false,
                        onChanged: widget.timelist[104].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[104].tsid, value!);
                                if (changes) {
                                  widget.timelist[104].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[105].startTime}-${widget.timelist[105].endTime}'),
                    Checkbox(
                        value: widget.timelist[105].availability ?? false,
                        onChanged: widget.timelist[105].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[105].tsid, value!);
                                if (changes) {
                                  widget.timelist[105].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[106].availability ?? false,
                        onChanged: widget.timelist[106].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[106].tsid, value!);
                                if (changes) {
                                  widget.timelist[106].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[107].availability ?? false,
                        onChanged: widget.timelist[107].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[107].tsid, value!);
                                if (changes) {
                                  widget.timelist[107].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[108].availability ?? false,
                        onChanged: widget.timelist[108].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[108].tsid, value!);
                                if (changes) {
                                  widget.timelist[108].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[109].availability ?? false,
                        onChanged: widget.timelist[109].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[109].tsid, value!);
                                if (changes) {
                                  widget.timelist[109].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[110].startTime}-${widget.timelist[110].endTime}'),
                    Checkbox(
                        value: widget.timelist[110].availability ?? false,
                        onChanged: widget.timelist[110].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[110].tsid, value!);
                                if (changes) {
                                  widget.timelist[110].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[111].availability ?? false,
                        onChanged: widget.timelist[111].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[111].tsid, value!);
                                if (changes) {
                                  widget.timelist[111].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[112].availability ?? false,
                        onChanged: widget.timelist[112].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[112].tsid, value!);
                                if (changes) {
                                  widget.timelist[112].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[113].availability ?? false,
                        onChanged: widget.timelist[113].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[113].tsid, value!);
                                if (changes) {
                                  widget.timelist[113].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[114].availability ?? false,
                        onChanged: widget.timelist[114].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[114].tsid, value!);
                                if (changes) {
                                  widget.timelist[114].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[115].startTime}-${widget.timelist[115].endTime}'),
                    Checkbox(
                        value: widget.timelist[115].availability ?? false,
                        onChanged: widget.timelist[115].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[115].tsid, value!);
                                if (changes) {
                                  widget.timelist[115].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[116].availability ?? false,
                        onChanged: widget.timelist[116].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[116].tsid, value!);
                                if (changes) {
                                  widget.timelist[116].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[117].availability ?? false,
                        onChanged: widget.timelist[117].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[117].tsid, value!);
                                if (changes) {
                                  widget.timelist[117].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[118].availability ?? false,
                        onChanged: widget.timelist[118].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[118].tsid, value!);
                                if (changes) {
                                  widget.timelist[118].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[119].availability ?? false,
                        onChanged: widget.timelist[119].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[119].tsid, value!);
                                if (changes) {
                                  widget.timelist[119].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[120].startTime}-${widget.timelist[120].endTime}'),
                    Checkbox(
                        value: widget.timelist[120].availability ?? false,
                        onChanged: widget.timelist[120].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[120].tsid, value!);
                                if (changes) {
                                  widget.timelist[120].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[121].availability ?? false,
                        onChanged: widget.timelist[121].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[121].tsid, value!);
                                if (changes) {
                                  widget.timelist[121].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[122].availability ?? false,
                        onChanged: widget.timelist[122].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[122].tsid, value!);
                                if (changes) {
                                  widget.timelist[122].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[123].availability ?? false,
                        onChanged: widget.timelist[123].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[123].tsid, value!);
                                if (changes) {
                                  widget.timelist[123].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[124].availability ?? false,
                        onChanged: widget.timelist[124].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[124].tsid, value!);
                                if (changes) {
                                  widget.timelist[124].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[125].startTime}-${widget.timelist[125].endTime}'),
                    Checkbox(
                        value: widget.timelist[125].availability ?? false,
                        onChanged: widget.timelist[125].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[125].tsid, value!);
                                if (changes) {
                                  widget.timelist[125].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[126].availability ?? false,
                        onChanged: widget.timelist[126].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[126].tsid, value!);
                                if (changes) {
                                  widget.timelist[126].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[127].availability ?? false,
                        onChanged: widget.timelist[127].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[127].tsid, value!);
                                if (changes) {
                                  widget.timelist[127].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[128].availability ?? false,
                        onChanged: widget.timelist[128].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[128].tsid, value!);
                                if (changes) {
                                  widget.timelist[128].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[129].availability ?? false,
                        onChanged: widget.timelist[129].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[129].tsid, value!);
                                if (changes) {
                                  widget.timelist[129].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[130].startTime}-${widget.timelist[130].endTime}'),
                    Checkbox(
                        value: widget.timelist[130].availability,
                        onChanged: (bool? value) {
                          widget.timelist[130].availability = value!;
                          setState(() {});
                        }),
                    Checkbox(
                        value: widget.timelist[131].availability,
                        onChanged: (bool? value) {
                          widget.timelist[131].availability = value!;
                          setState(() {});
                        }),
                    Checkbox(
                        value: widget.timelist[132].availability ?? false,
                        onChanged: widget.timelist[132].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[132].tsid, value!);
                                if (changes) {
                                  widget.timelist[132].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[133].availability ?? false,
                        onChanged: widget.timelist[133].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[133].tsid, value!);
                                if (changes) {
                                  widget.timelist[133].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[134].availability ?? false,
                        onChanged: widget.timelist[134].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[134].tsid, value!);
                                if (changes) {
                                  widget.timelist[134].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[135].startTime}-${widget.timelist[135].endTime}'),
                    Checkbox(
                        value: widget.timelist[135].availability ?? false,
                        onChanged: widget.timelist[135].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[135].tsid, value!);
                                if (changes) {
                                  widget.timelist[135].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[136].availability ?? false,
                        onChanged: widget.timelist[136].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[136].tsid, value!);
                                if (changes) {
                                  widget.timelist[136].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[137].availability ?? false,
                        onChanged: widget.timelist[137].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[137].tsid, value!);
                                if (changes) {
                                  widget.timelist[137].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[138].availability ?? false,
                        onChanged: widget.timelist[138].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[138].tsid, value!);
                                if (changes) {
                                  widget.timelist[138].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[139].availability ?? false,
                        onChanged: widget.timelist[139].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[139].tsid, value!);
                                if (changes) {
                                  widget.timelist[139].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[140].startTime}-${widget.timelist[140].endTime}'),
                    Checkbox(
                        value: widget.timelist[140].availability ?? false,
                        onChanged: widget.timelist[140].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[140].tsid, value!);
                                if (changes) {
                                  widget.timelist[140].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[141].availability ?? false,
                        onChanged: widget.timelist[141].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[141].tsid, value!);
                                if (changes) {
                                  widget.timelist[141].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[142].availability ?? false,
                        onChanged: widget.timelist[142].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[142].tsid, value!);
                                if (changes) {
                                  widget.timelist[142].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[143].availability ?? false,
                        onChanged: widget.timelist[143].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[143].tsid, value!);
                                if (changes) {
                                  widget.timelist[143].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[144].availability ?? false,
                        onChanged: widget.timelist[144].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[144].tsid, value!);
                                if (changes) {
                                  widget.timelist[144].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
              Table(
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  TableRow(children: [
                    Text(
                        '${widget.timelist[145].startTime}-${widget.timelist[145].endTime}'),
                    Checkbox(
                        value: widget.timelist[145].availability ?? false,
                        onChanged: widget.timelist[145].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[145].tsid, value!);
                                if (changes) {
                                  widget.timelist[145].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[146].availability ?? false,
                        onChanged: widget.timelist[146].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[146].tsid, value!);
                                if (changes) {
                                  widget.timelist[146].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[147].availability ?? false,
                        onChanged: widget.timelist[147].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[147].tsid, value!);
                                if (changes) {
                                  widget.timelist[147].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[148].availability ?? false,
                        onChanged: widget.timelist[148].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[148].tsid, value!);
                                if (changes) {
                                  widget.timelist[148].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                    Checkbox(
                        value: widget.timelist[149].availability ?? false,
                        onChanged: widget.timelist[149].availability != null
                            ? (bool? value) async {
                                await updateAvailability(
                                    widget.timelist[149].tsid, value!);
                                if (changes) {
                                  widget.timelist[149].availability = value;
                                  setState(() {});
                                }
                              }
                            : null),
                  ]),
                ],
              ),
              //========================
            ],
          ),
        ),
      ),
    );
  }
}
