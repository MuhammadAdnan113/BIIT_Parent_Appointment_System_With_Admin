import 'dart:convert';
import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class UpdateStatus extends StatefulWidget {
  List<NotificationModel> notification;
  bool todayOrNot;
  UpdateStatus({Key? key, required this.notification, required this.todayOrNot})
      : super(key: key);

  @override
  State<UpdateStatus> createState() => UpdateStatusState();
}

class UpdateStatusState extends State<UpdateStatus> {
  // Variables
  DateTime? pickedDate;
  String formattedDate = '';
  TextEditingController _remark = TextEditingController(text: '');
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  NotificationModel? appointment;

  //===== API==========
  String errormsg = '';
  int _statuscode = 0;
  List<TimeSlot> timeslot = [];

  Future<void> apiGetTimeSlotRole(String role) async {
    String url = '${Variables.baseurl}/admin/GetTimeSlotRole?role=$role';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      timeslot = listt.map((e) => TimeSlot.fromMap(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  bool updated = false;
  Future<void> apiUpdateMeetingStatus(
      int mid, String status, String remarks) async {
    String url =
        '${Variables.baseurl}/admin/UpdateMeetingStatus?mid=$mid&status=$status&remarks=$remarks';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      setState(() {
        updated = true;
        errormsg = response.body;
      });
    } else {
      errormsg = response.body;
    }
  }

  Future<void> rescheduleAppointment(int mid, String newdate) async {
    String url =
        '${Variables.baseurl}/Admin/ReSheduleMeeting?mid=$mid&date=$newdate';
    var response = await http.get(Uri.parse(url));
    _statuscode = response.statusCode;
    setState(() {
      errormsg = response.body;
    });
  }

  //==== END API ==========================

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: widget.todayOrNot == true
            ? const Text('Today\'s Appointmets')
            : const Text("All Appointments"),
      ),
      body: SingleChildScrollView(
        child: widget.notification.isEmpty
            ? const Center(
                child: Text(
                  'No Appointments are available',
                  style: TextStyle(color: Colors.red),
                ),
              )
            : Container(
                height: myheight * 0.87,
                margin: EdgeInsets.all(spacewidth),
                child: ListView.builder(
                  itemCount: widget.notification.length,
                  itemBuilder: ((context, index) {
                    NotificationModel item =
                        widget.notification.elementAt(index);
                    if (widget.todayOrNot) {
                      if (item.status != "Request" &&
                          item.status != "Reschedualed" &&
                          item.date == Variables.systemDate) {
                        return Column(
                          children: [
                            Row(
                              children: [
                                const Text(
                                  'Reg. No:',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  width: spacewidth,
                                ),
                                Text(item.regNo)
                              ],
                            ),
                            SizedBox(
                              height: spaceheight * 0.30,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'Reason:',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  width: spacewidth,
                                ),
                                Text(item.reason)
                              ],
                            ),
                            SizedBox(
                              height: spaceheight * 0.30,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'Date:',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  width: spacewidth,
                                ),
                                Text(item.date)
                              ],
                            ),
                            SizedBox(
                              height: spaceheight * 0.30,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'Start Time:',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  width: spacewidth,
                                ),
                                Text(item.startTime)
                              ],
                            ),
                            SizedBox(
                              height: spaceheight * 0.30,
                            ),
                            Row(
                              children: [
                                const Text(
                                  'End Time:',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  width: spacewidth,
                                ),
                                Text(item.endTime),
                              ],
                            ),
                            SizedBox(
                              height: spaceheight * 0.30,
                            ),
                            item.status == "Wait"
                                ? const Text(
                                    "Requested to wait",
                                    style: TextStyle(
                                        color: Colors.red,
                                        fontWeight: FontWeight.bold),
                                  )
                                : Row(
                                    children: [
                                      const Text(
                                        'Status:',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(
                                        width: spacewidth,
                                      ),
                                      ElevatedButton(
                                        onPressed: () async {
                                          await showDialog(
                                              context: context,
                                              barrierDismissible: false,
                                              builder: (cont) {
                                                return AlertDialog(
                                                  title: const Text(
                                                      "Appointment Remarks"),
                                                  actions: [
                                                    Form(
                                                      key: _formKey,
                                                      child: getTextFormField(
                                                        hintText:
                                                            'Enter Remarks',
                                                        controller: _remark,
                                                        lbltext:
                                                            'Remarks about appointment',
                                                        maxlength: 40,
                                                        inputType: TextInputType
                                                            .emailAddress,
                                                        suffixIcon: const Icon(
                                                          Icons.email,
                                                          color:
                                                              Colors.redAccent,
                                                        ),
                                                        validator:
                                                            MultiValidator(
                                                          [
                                                            RequiredValidator(
                                                                errorText:
                                                                    'Field cannot be empty'),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: spaceheight,
                                                    ),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        TextButton(
                                                          onPressed: () async {
                                                            if (_formKey
                                                                .currentState!
                                                                .validate()) {
                                                              await apiUpdateMeetingStatus(
                                                                  item.nid,
                                                                  "Held",
                                                                  _remark.text);
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();
                                                              await getAlertDialog(
                                                                  context,
                                                                  'Alert',
                                                                  errormsg);
                                                              if (updated) {
                                                                widget
                                                                    .notification
                                                                    .remove(
                                                                        item);
                                                                setState(() {});
                                                              }
                                                            }

                                                            //Function will be here
                                                          },
                                                          child: const Text(
                                                              "Update"),
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                );
                                              });
                                        },
                                        style: ElevatedButton.styleFrom(
                                            minimumSize: const Size(90, 37)),
                                        child: const Text('Held'),
                                      ),
                                      SizedBox(
                                        width: spacewidth,
                                      ),
                                      ElevatedButton.icon(
                                        onPressed: () async {
                                          await apiUpdateMeetingStatus(
                                              item.nid, "Wait", 'remarks here');
                                          await getAlertDialog(
                                              context, "Alert", errormsg);
                                          widget.notification
                                              .elementAt(index)
                                              .status = "Wait";
                                          setState(() {});
                                        },
                                        style: ElevatedButton.styleFrom(
                                            minimumSize: const Size(90, 37)),
                                        icon: const Icon(Icons.watch_later),
                                        label: const Text("Wait"),
                                      ),
                                      SizedBox(
                                        width: spacewidth,
                                      ),
                                      ElevatedButton(
                                        onPressed: () async {
                                          pickedDate = await showDatePicker(
                                              context: context,
                                              initialDate: DateTime.now(),
                                              firstDate: DateTime.now(),
                                              //DateTime.now() - not to allow to choose before today.
                                              lastDate: DateTime(2100));

                                          if (pickedDate != null) {
                                            print(
                                                pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                                            formattedDate =
                                                DateFormat('d/M/yyyy')
                                                    .format(pickedDate!);
                                            print(
                                                formattedDate); //formatted date output using intl package =>  2021-03-16
                                            setState(() {
                                              //set output date to TextField value.
                                            });
                                            if (pickedDate != null) {
                                              await rescheduleAppointment(
                                                  item.nid, formattedDate);
                                              await getAlertDialog(
                                                  context, 'Alert', errormsg);
                                              if (_statuscode == 200) {
                                                widget.notification
                                                    .remove(item);
                                                setState(() {});
                                              }
                                            } else {
                                              getAlertDialog(
                                                  context,
                                                  'Date Required',
                                                  "Please Select Valid Date");
                                            }
                                          }
                                        },
                                        style: ElevatedButton.styleFrom(
                                            minimumSize: const Size(90, 37)),
                                        child: const Text('Reschedule'),
                                      ),
                                    ],
                                  ),
                            SizedBox(
                              height: spaceheight * 0.30,
                            ),
                            const Divider(
                              thickness: 2,
                            ),
                          ],
                        );
                      } else {
                        return const Text('');
                      }
                    } else {
                      return Column(
                        children: [
                          Row(
                            children: [
                              const Text(
                                'Reg. No:',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: spacewidth,
                              ),
                              Text(item.regNo)
                            ],
                          ),
                          SizedBox(
                            height: spaceheight * 0.30,
                          ),
                          Row(
                            children: [
                              const Text(
                                'Reason:',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: spacewidth,
                              ),
                              Text(item.reason)
                            ],
                          ),
                          SizedBox(
                            height: spaceheight * 0.30,
                          ),
                          Row(
                            children: [
                              const Text(
                                'Date:',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: spacewidth,
                              ),
                              Text(item.date)
                            ],
                          ),
                          SizedBox(
                            height: spaceheight * 0.30,
                          ),
                          Row(
                            children: [
                              const Text(
                                'Start Time:',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: spacewidth,
                              ),
                              Text(item.startTime)
                            ],
                          ),
                          SizedBox(
                            height: spaceheight * 0.30,
                          ),
                          Row(
                            children: [
                              const Text(
                                'End Time:',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: spacewidth,
                              ),
                              Text(item.endTime),
                            ],
                          ),
                          SizedBox(
                            height: spaceheight * 0.30,
                          ),
                          item.status == "Wait"
                              ? const Text(
                                  "Requested to wait",
                                  style: TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold),
                                )
                              : Row(
                                  children: [
                                    const Text(
                                      'Status:',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      width: spacewidth,
                                    ),
                                    ElevatedButton(
                                      onPressed: () async {
                                        await showDialog(
                                            context: context,
                                            barrierDismissible: false,
                                            builder: (cont) {
                                              return AlertDialog(
                                                title: const Text(
                                                    "Appointment Remarks"),
                                                actions: [
                                                  Form(
                                                    key: _formKey,
                                                    child: getTextFormField(
                                                      hintText: 'Enter Remarks',
                                                      controller: _remark,
                                                      lbltext:
                                                          'Remarks about appointment',
                                                      maxlength: 40,
                                                      inputType: TextInputType
                                                          .emailAddress,
                                                      suffixIcon: const Icon(
                                                        Icons.email,
                                                        color: Colors.redAccent,
                                                      ),
                                                      validator: MultiValidator(
                                                        [
                                                          RequiredValidator(
                                                              errorText:
                                                                  'Field cannot be empty'),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: spaceheight,
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      TextButton(
                                                        onPressed: () async {
                                                          if (_formKey
                                                              .currentState!
                                                              .validate()) {
                                                            await apiUpdateMeetingStatus(
                                                                item.nid,
                                                                "Held",
                                                                _remark.text);
                                                            Navigator.of(
                                                                    context)
                                                                .pop();
                                                            await getAlertDialog(
                                                                context,
                                                                'Alert',
                                                                errormsg);
                                                            if (updated) {
                                                              widget
                                                                  .notification
                                                                  .remove(item);
                                                              setState(() {});
                                                            }
                                                          }

                                                          //Function will be here
                                                        },
                                                        child: const Text(
                                                            "Update"),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              );
                                            });
                                      },
                                      style: ElevatedButton.styleFrom(
                                          minimumSize: const Size(90, 37)),
                                      child: const Text('Held'),
                                    ),
                                    SizedBox(
                                      width: spacewidth,
                                    ),
                                    ElevatedButton.icon(
                                      onPressed: () async {
                                        await apiUpdateMeetingStatus(
                                            item.nid, "Wait", 'remarks here');
                                        await getAlertDialog(
                                            context, "Alert", errormsg);
                                        widget.notification
                                            .elementAt(index)
                                            .status = "Wait";
                                        setState(() {});
                                      },
                                      style: ElevatedButton.styleFrom(
                                          minimumSize: const Size(90, 37)),
                                      icon: const Icon(Icons.watch_later),
                                      label: const Text("Wait"),
                                    ),
                                    SizedBox(
                                      width: spacewidth,
                                    ),
                                    ElevatedButton(
                                      onPressed: () async {
                                        pickedDate = await showDatePicker(
                                            context: context,
                                            initialDate: DateTime.now(),
                                            firstDate: DateTime.now(),
                                            //DateTime.now() - not to allow to choose before today.
                                            lastDate: DateTime(2100));

                                        if (pickedDate != null) {
                                          print(
                                              pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                                          formattedDate = DateFormat('d/M/yyyy')
                                              .format(pickedDate!);
                                          print(
                                              formattedDate); //formatted date output using intl package =>  2021-03-16
                                          setState(() {
                                            //set output date to TextField value.
                                          });
                                          if (pickedDate != null) {
                                            await rescheduleAppointment(
                                                item.nid, formattedDate);
                                            await getAlertDialog(
                                                context, 'Alert', errormsg);
                                            String id = Variables.getLoginID;
                                            if (_statuscode == 200) {
                                              widget.notification.remove(item);
                                              setState(() {});
                                            }
                                          } else {
                                            getAlertDialog(
                                                context,
                                                'Date Required',
                                                "Please Select Valid Date");
                                          }
                                        }
                                      },
                                      style: ElevatedButton.styleFrom(
                                          minimumSize: const Size(90, 37)),
                                      child: const Text('Reschedule'),
                                    ),
                                  ],
                                ),
                          SizedBox(
                            height: spaceheight * 0.30,
                          ),
                          const Divider(
                            thickness: 2,
                          ),
                        ],
                      );
                    }
                  }),
                  shrinkWrap: true,
                ),
              ),
      ),
    );
  }
}
