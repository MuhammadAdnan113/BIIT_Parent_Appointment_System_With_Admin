import 'dart:convert';
import 'package:biit_parent_appointment_system/Models/HistoryModel.dart';
import 'package:biit_parent_appointment_system/Models/WaitingModel.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/WaitingList.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../../API/APIHandler.dart';
import '../../Models/AttendanceModel.dart';
import '../../Models/CGPAModel.dart';
import '../../Models/Models.dart';
import '../../Models/NotificationModel.dart';
import '../../Variables/Variables.dart';
import '../../Widgets/Widgets.dart';
import 'Admin_SetAppointment.dart';
import 'Admin_Availability.dart';
import 'Admin_History.dart';
import 'Admin_Notification.dart';
import 'UpdateStatus.dart';

class AdminDashboard extends StatefulWidget {
  int? notifications;
  final UserData user;
  AdminDashboard({Key? key, this.notifications, required this.user})
      : super(key: key);

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
//=====API Variables=====
  bool success = false;
  String errormsg = '';

  DateTime? pickedDate;
  String formattedDate = Variables.systemDate;

  //=====API Variables=====
  List<NotificationModel> notifications = [];
  Future<void> getNotification(String admin) async {
    String url = '${Variables.baseurl}/Admin/GetNotification?adminid=$admin';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      notifications = listt.map((e) => NotificationModel.fromJson(e)).toList();
      setState(() {
        success = true;
      });
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//==================================

  List<HistoryModel> history = [];

  Future<void> apiGetHistory(String admin) async {
    String url = '${Variables.baseurl}/Admin/GetHistory?adminid=$admin';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      history = listt.map((e) => HistoryModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  //==========================
  List<CGPAModel> lowCGPA = [];
  Future<void> apiGetLowCGPA() async {
    String url = '${Variables.baseurl}/admin/GetLowCGPAStudents';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      lowCGPA = listt.map((e) => CGPAModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//===============================
  List<AttendanceModel> shortAttendance = [];
  Future<void> apiGetShortAttendance() async {
    String url = '${Variables.baseurl}/admin/GetShortAttendance';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      shortAttendance = listt.map((e) => AttendanceModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }
  //==============================

  List<TimeSlot> timelist = [];
  Future<void> apiGetTimeSlot() async {
    String url =
        '${Variables.baseurl}/admin/GetTimeSlot?adminid=${widget.user.cnic}';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      timelist = listt.map((e) => TimeSlot.fromMap(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  //==================
  List<WaitingModel> waitinglist = [];
  Future<void> apiGetWaitingList() async {
    String url = '${Variables.baseurl}/Admin/GetWaitingList';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      waitinglist = listt.map((e) => WaitingModel.fromJson(e)).toList();
      setState(() {});
    } else {
      getAlertDialog(context, 'Alert', response.body);
    }
  }

  var now = DateTime.now();
  var formatter = DateFormat('d/M/yyyy');

  Future<void> reAdjustAppointment(String admin, String date) async {
    String url =
        '${Variables.baseurl}/Admin/ReAdjustMeeting?adminid=$admin&date=$date';
    var response = await http.get(Uri.parse(url));
    await getAlertDialog(context, 'Alert', response.body);
  }
  //====== API ===============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('Welcome '),
          Text(
            widget.user.username,
            style: const TextStyle(
                fontSize: 22.0,
                fontWeight: FontWeight.bold,
                color: Colors.black),
          )
        ]),
        centerTitle: true,
        titleSpacing: 00.0,
        toolbarHeight: 60.2,
        toolbarOpacity: 0.8,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(25),
              bottomLeft: Radius.circular(25)),
        ),
        elevation: 0.00,
        backgroundColor: Colors.greenAccent[400],
        actions: [
          IconButton(
            onPressed: () async {
              await getcountNotification('Admin', Variables.getLoginID);
              if (getResponse.statusCode == 200) {
                widget.notifications = int.parse(getResponse.body);
                setState(() {});
              }
            },
            icon: const Icon(Icons.refresh),
          ),
          Stack(
            children: [
              IconButton(
                  onPressed: () async {
                    await getNotification(widget.user.cnic);
                    if (success) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (cont) =>
                              AdminNotification(notification: notifications)));
                    } else {
                      getAlertDialog(context, 'Alert', errormsg);
                    }
                  },
                  icon: const Icon(
                    Icons.notifications,
                    size: 35,
                  )),
              Positioned(
                left: 22,
                bottom: 27,
                child: Text(
                  '${widget.notifications}',
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
          const SizedBox(
            width: 10,
          ),
        ],
      ),
      body: WillPopScope(
        onWillPop: () => showLogOutDialog(context),
        child: SingleChildScrollView(
          child: Container(
            alignment: Alignment.center,
            margin: EdgeInsets.only(top: mywidth * 0.08),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => AdminSetAppointment(
                              user: widget.user,
                            )));
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text('Set Appointment'),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                ElevatedButton(
                  onPressed: () async {
                    await getNotification(widget.user.cnic);
                    if (notifications.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => UpdateStatus(
                                notification: notifications,
                                todayOrNot: true,
                              )));
                    } else {
                      getAlertDialog(context, 'Alert', errormsg);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text('Today\'s Appointments'),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                ElevatedButton(
                  onPressed: () async {
                    await getNotification(widget.user.cnic);
                    if (notifications.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => UpdateStatus(
                                notification: notifications,
                                todayOrNot: false,
                              )));
                    } else {
                      getAlertDialog(context, 'Alert', errormsg);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text('All Appointments'),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                ElevatedButton.icon(
                  onPressed: () async {
                    await apiGetWaitingList();
                    if (waitinglist.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) =>
                              AdminWaitingList(waitinglist: waitinglist)));
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  icon: const Icon(Icons.watch_later),
                  label: const Text('Waiting List'),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                ElevatedButton(
                  onPressed: () async {
                    await apiGetTimeSlot();
                    if (timelist.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => Availability(
                              user: widget.user, timelist: timelist)));
                    } else {
                      getAlertDialog(context, "Alert", errormsg);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text('My Schedule'),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                ElevatedButton(
                  onPressed: () async {
                    pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now(),
                        //DateTime.now() - not to allow to choose before today.
                        lastDate: DateTime(2100));

                    if (pickedDate != null) {
                      print(
                          pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                      formattedDate =
                          DateFormat('d/M/yyyy').format(pickedDate!);
                      print(
                          formattedDate); //formatted date output using intl package =>  2021-03-16
                      setState(() {
                        //set output date to TextField value.
                      });
                      if (pickedDate != null) {
                        // Function here
                        await showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (cont) {
                              return AlertDialog(
                                title: const Text('Are You Sure?'),
                                content: Text(
                                    'Today\'s ($formattedDate) Appointments will be shifted with other Admin'),
                                actions: [
                                  TextButton(
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                      child: const Text("No")),
                                  TextButton(
                                      onPressed: () async {
                                        await reAdjustAppointment(
                                            Variables.getLoginID,
                                            formattedDate);
                                        Navigator.of(context).pop();
                                      },
                                      child: const Text("Yes")),
                                ],
                              );
                            });
                      }
                    }
                    //==========
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text('Re-Adjust Appointments'),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                ElevatedButton(
                  onPressed: () async {
                    await apiGetHistory(widget.user.cnic);
                    if (history.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => AdminHistory(
                                notification: history,
                              )));
                    } else {
                      getAlertDialog(context, 'Alert', errormsg);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text('History'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
