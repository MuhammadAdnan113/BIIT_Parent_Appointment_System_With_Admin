import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ReferTo extends StatefulWidget {
  String? title;
  List<TimeSlot> timeslot;
  NotificationModel request;
  ReferTo(
      {Key? key,
      required this.title,
      required this.timeslot,
      required this.request})
      : super(key: key);

  @override
  State<ReferTo> createState() => _ReferToState();
}

class _ReferToState extends State<ReferTo> {
  //===== API==========
  String errormsg = '';
  bool changes = false;
  Future<void> apiReferAppointment(String role, int tsid, int mid) async {
    String url =
        '${Variables.baseurl}/admin/ReferTo?mid=$mid&refer=$role&tsid=$tsid';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      setState(() {
        changes = true;
        errormsg = response.body;
      });
    }
    setState(() {
      errormsg = response.body;
    });
  }

  //==== END API ==========================

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text('Refer to ${widget.title}'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.all(10),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('RegNo: '),
                  Text(
                    widget.request.regNo,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: mywidth * 0.10,
                  ),
                  const Text('Reason: '),
                  Text(
                    widget.request.reason,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(
                height: myheight * 0.02,
              ),
              widget.timeslot.isEmpty
                  ? const Center(
                      child: Text(
                        'No TimeSlot Available for Appointment',
                        style: TextStyle(
                            color: Colors.red,
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold),
                      ),
                    )
                  : SizedBox(
                      height: myheight * 0.7,
                      child: GridView.builder(
                        shrinkWrap: true,
                        gridDelegate:
                            const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 200,
                          childAspectRatio: 1.4,
                          crossAxisSpacing: 25,
                          mainAxisSpacing: 25,
                        ),
                        itemCount: widget.timeslot.length,
                        itemBuilder: (context, index) {
                          TimeSlot item = widget.timeslot.elementAt(index);
                          return SizedBox(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(item.day),
                                    ElevatedButton(
                                      onPressed: () async {
                                        String role = widget.title ==
                                                'Project Commitee'
                                            ? 'Project'
                                            : widget.title == "Deputy Director"
                                                ? "DDirector"
                                                : widget.title!;
                                        await apiReferAppointment(role,
                                            item.tsid, widget.request.nid);
                                        await getAlertDialog(
                                            context, 'Alert', errormsg);
                                        if (changes) {
                                          widget.timeslot.remove(item);
                                          setState(() {});
                                        }
                                      },
                                      child: Text(
                                          '${item.startTime}-${item.endTime}'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
