import 'dart:convert';
import 'package:biit_parent_appointment_system/Screens/ParentSide/Parent_Dashboard.dart';
import 'package:biit_parent_appointment_system/Screens/ReferedSide/ReferredTo_Dashboard.dart';
import 'package:biit_parent_appointment_system/Screens/StudentSide/Student_Dashboard.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import '../../Models/Models.dart';
import '../../Variables/Variables.dart';
import '../AdminSide/Admin_Dashboard.dart';
import 'Account_Verify.dart';
import 'Forgot_Password.dart';
import 'Onboarding.dart';
import 'Signup_Parent.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController _username = TextEditingController();
  TextEditingController _password = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

//====== Connectivity ==========================

  var subscription;
  String status = 'Offline';

  @override
  initState() {
    super.initState();
    _username.text = "";
    _password.text = "";
    subscription = Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult result) {
      // Got a new connectivity status!
      if (result == ConnectivityResult.none) {
        setState(() {
          status = 'Offline';
        });
      } else {
        setState(() {
          status = 'Online';
        });
      }
    });
  }

// Be sure to cancel subscription after you are done
  @override
  dispose() {
    super.dispose();
    notification = 0;
    subscription.cancel();
  }

//====== End Connectivity =======================

  //=====API Variables=====
  late UserData userdata;
  String errormsg = '';
  bool loading = false;
  int notification = 0;

  //========= API ========================
  Future<void> login(String username, String password) async {
    setState(() {
      loading = true;
    });
    String url =
        '${Variables.baseurl}/User/logIn?username=$username&pass=$password';

    var response = await http.get(Uri.parse(url)).timeout(
      const Duration(seconds: 20),
      onTimeout: () {
        // Time has run out, do what you wanted to do.
        return http.Response(
            'Connection Timeout', 408); // Request Timeout response status code
      },
    );
    if (response.statusCode == 200) {
      UserData data = UserData.fromMap(json.decode(response.body));
      setState(() {
        loading = false;
        userdata = data;
      });
    } else {
      await getAlertDialog(context, 'Alert', response.body);
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> countNotification(String controller, String id) async {
    String url = '${Variables.baseurl}/$controller/countnotification?id=$id';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      notification = int.parse(response.body);
      setState(() {});
    }
  }

  //======== End API ===========
  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: Size(mywidth, 4.0),
          child: Container(
            color: status == 'Offline' ? Colors.redAccent : Colors.green,
            child: Text(status),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              prefs.setBool("showHome", false);
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => const onboarding()),
              );
            },
          )
        ],
      ),
      body: WillPopScope(
        onWillPop: _showExitDialog,
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.only(
                left: mywidth * 0.10,
                right: mywidth * 0.10,
                top: mywidth * 0.04),
            child: Column(
              children: [
                Center(
                  child: Image.asset(
                    'assets/images/biit.png',
                    fit: BoxFit.fill,
                    height: myheight * 0.20,
                    width: mywidth * 0.35,
                    alignment: Alignment.center,
                  ),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                Form(
                  key: _formKey,
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      getTextFormField(
                        hintText: 'Enter User Name',
                        controller: _username,
                        lbltext: 'User Name',
                        maxlength: 9,
                        inputType: TextInputType.text,
                        suffixIcon: const Icon(
                          Icons.person,
                          color: Colors.orange,
                        ),
                        validator: MultiValidator([
                          RequiredValidator(errorText: 'Field cannot be empty')
                        ]),
                      ),
                      SizedBox(
                        height: spaceheight,
                      ),
                      getTextFormField(
                        hintText: 'Password',
                        controller: _password,
                        lbltext: 'Password',
                        maxlength: 10,
                        inputType: TextInputType.text,
                        suffixIcon: const Icon(
                          Icons.lock,
                          color: Colors.redAccent,
                        ),
                        validator: MultiValidator([
                          RequiredValidator(errorText: 'Field cannot be empty')
                        ]),
                        obscureText: true,
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.center,
                //   children: [
                //     const Text(
                //       'Login As ',
                //       style:
                //           TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                //     ),
                //     SizedBox(
                //       width: mywidth * 0.15,
                //     ),
                //     DropdownButton(
                //         // Initial Value
                //         value: _role,
                //         // Down Arrow Icon
                //         icon: const Icon(Icons.keyboard_arrow_down),
                //         // Array list of items
                //         items: _rolelist.map((String items) {
                //           return DropdownMenuItem(
                //             value: items,
                //             child: Text(items),
                //           );
                //         }).toList(),
                //         // After selecting the desired option,it will
                //         // change button value to selected value
                //         onChanged: (String? newValue) {
                //           setState(() {
                //             _role = newValue!;
                //           });
                //         }),
                //   ],
                // ),
                const SizedBox(
                  height: 5,
                ),
                loading == false
                    ? ElevatedButton(
                        onPressed: () async {
                          if (status == 'Online') {
                            if (_formKey.currentState!.validate()) {
                              await login(_username.text, _password.text);
                              if (userdata.username.isNotEmpty) {
                                _username.text = '';
                                _password.text = '';
                                if (userdata.role != 'Student') {
                                  await countNotification(
                                      userdata.role, userdata.cnic);
                                  Variables.setLoginID(userdata.cnic);
                                }
                                if (userdata.role == 'Parent') {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (cont) => ParentDasgboard(
                                            notification: notification,
                                            user: userdata,
                                          )));
                                } else if (userdata.role == 'Admin') {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (cont) => AdminDashboard(
                                            notifications: notification,
                                            user: userdata,
                                          )));
                                } else if (userdata.role == 'Datacell' ||
                                    userdata.role == 'Project Committee' ||
                                    userdata.role == 'Accountant' ||
                                    userdata.role == 'Director' ||
                                    userdata.role == 'Deputy Director') {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (cont) => ReferDashboard(
                                            user: userdata,
                                            notifications: notification,
                                          )));
                                } else if (userdata.role == 'Student') {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (cont) => StudentDashboard(
                                            user: userdata,
                                          )));
                                }
                              } else {
                                getAlertDialog(context, 'Alert', errormsg);
                              }
                            }
                          } else {
                            getAlertDialog(context, "Connection Failed",
                                'Connect to Network to use Application');
                            // showDialog(
                            //     context: context,
                            //     barrierDismissible: false,
                            //     builder: (cont) {
                            //       return AlertDialog(
                            //         title: const Text("Connection Failed"),
                            //         content: const Text(
                            //             'Connect to Network to use Application'),
                            //         actions: [
                            //           TextButton(
                            //               onPressed: () {
                            //                 Navigator.of(context).pop();
                            //               },
                            //               child: const Text("Ok")),
                            //         ],
                            //       );
                            //     });
                          }
                        },
                        child: const Text('Login'),
                      )
                    : const CircularProgressIndicator.adaptive(),
                Row(
                  children: [
                    const Text('Don\'t have an Account?'),
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (cont) => const SignupParent()));
                      },
                      child: const Text('Signup'),
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Text('Account not Verified?'),
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const Verify()));
                      },
                      child: const Text('Verify'),
                    ),
                  ],
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const ForgotPassword()));
                  },
                  child: const Text('Forgot Password'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<bool> _showExitDialog() async {
    return await showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => AlertDialog(
              title: const Text("Exit app"),
              content: const Text("Do you want to Exit this app?"),
              actions: [
                TextButton.icon(
                    onPressed: () {
                      Navigator.of(context).pop(false);
                    },
                    icon: const Icon(Icons.cancel),
                    label: const Text('No')),
                TextButton.icon(
                    onPressed: () {
                      Navigator.of(context).pop(true);
                    },
                    icon: const Icon(Icons.logout),
                    label: const Text('Yes')),
              ],
            ));
  }
}
