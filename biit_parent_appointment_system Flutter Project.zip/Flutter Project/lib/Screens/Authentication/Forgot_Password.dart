import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

import '../../Variables/Variables.dart';
import '../../Widgets/Widgets.dart';
import 'package:http/http.dart' as http;

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  TextEditingController _email = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  //=====API Variables=====
  String errormsg = '';
  //========= API ==============

  Future<void> forgetPassword(String email) async {
    String url = '${Variables.baseurl}/User/ForgetPassword?email=$email';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      setState(() {
        errormsg = response.body;
      });
    } else {
      setState(() {
        errormsg = response.body.toString();
      });
    }
  }
  //=====End API ============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forget Password'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(
              left: mywidth * 0.10, right: mywidth * 0.10, top: mywidth * 0.04),
          child: Column(
            children: [
              SizedBox(
                height: spaceheight,
              ),
              const Text(
                'Enter your Email ! to get\nUsername and Password',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: spaceheight,
              ),
              Form(
                key: _formKey,
                child: getTextFormField(
                  hintText: 'Enter Email',
                  controller: _email,
                  lbltext: 'Enter Email',
                  maxlength: 25,
                  inputType: TextInputType.emailAddress,
                  suffixIcon: const Icon(
                    Icons.email,
                    color: Colors.redAccent,
                  ),
                  validator: MultiValidator(
                    [
                      RequiredValidator(errorText: 'Field cannot be empty'),
                      EmailValidator(errorText: 'Enter Valid Email')
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    await forgetPassword(_email.text);
                    await getAlertDialog(context, 'Alert', errormsg);
                  }
                },
                child: const Text('Send Email'),
              ),
              SizedBox(
                height: myheight * 0.03,
              ),
              SizedBox(
                height: myheight * 0.15,
                width: mywidth,
                child: const Text(
                    'After sending Email Check your Email for Username and Password'),
              ),
              SizedBox(
                height: spaceheight,
              ),
              SizedBox(
                height: spaceheight,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
