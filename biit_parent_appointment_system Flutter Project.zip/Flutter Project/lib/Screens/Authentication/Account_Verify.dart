import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import '../../Variables/Variables.dart';
import '../../Widgets/Widgets.dart';
import 'package:http/http.dart' as http;

class Verify extends StatefulWidget {
  const Verify({Key? key}) : super(key: key);

  @override
  State<Verify> createState() => _VerifyState();
}

class _VerifyState extends State<Verify> {
  TextEditingController _otp = TextEditingController();
  TextEditingController _email = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  GlobalKey<FormState> _emailKey = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();
    errormsg = '';
  }

  //=====API Variables=====
  String errormsg = '';
  //========= API ==============

  Future<void> verifyAccount(int code) async {
    var response = await http
        .get(Uri.parse("${Variables.baseurl}/User/verifyOTP?code=$code"));
    if (response.statusCode == 200) {
      setState(() {
        errormsg = response.body;
      });
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//========= API ==============

  Future<void> resendOTP(String email) async {
    var response = await http
        .get(Uri.parse("${Variables.baseurl}/User/resendOTP?email=$email"));
    setState(() {
      errormsg = response.body;
    });
  }

  //=====End API ============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Account Verification'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(
              left: mywidth * 0.10, right: mywidth * 0.10, top: mywidth * 0.04),
          child: Column(
            children: [
              SizedBox(
                height: spaceheight,
              ),
              Form(
                key: _formKey,
                child: getTextFormField(
                  hintText: 'Enter OTP',
                  controller: _otp,
                  lbltext: 'Enter OTP',
                  maxlength: 4,
                  inputType: TextInputType.number,
                  suffixIcon: const Icon(
                    Icons.key,
                    color: Colors.orange,
                  ),
                  validator: MultiValidator(
                    [
                      RequiredValidator(errorText: 'Field cannot be empty'),
                      MinLengthValidator(4, errorText: '4 digit OTP'),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: spaceheight,
              ),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    int code = int.parse(_otp.text);
                    print(code);
                    await verifyAccount(code);
                    await getAlertDialog(context, "Alert", errormsg);
                  }
                },
                child: const Text('Verify'),
              ),
              SizedBox(
                height: spaceheight,
              ),
              const Text('Check your Email for OTP'),
              SizedBox(
                height: spaceheight,
              ),
              const Divider(
                thickness: 2,
              ),
              SizedBox(
                height: spaceheight,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Not Recieved OTP?'),
                  SizedBox(
                    width: spacewidth,
                  ),
                  TextButton(
                    onPressed: () {
                      showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (cont) {
                            return AlertDialog(
                              title: const Text("Resend OTP"),
                              actions: [
                                Form(
                                  key: _emailKey,
                                  child: getTextFormField(
                                    hintText: 'Enter Email',
                                    controller: _email,
                                    lbltext: 'Enter Email',
                                    maxlength: 25,
                                    inputType: TextInputType.emailAddress,
                                    suffixIcon: const Icon(
                                      Icons.email,
                                      color: Colors.redAccent,
                                    ),
                                    validator: MultiValidator(
                                      [
                                        RequiredValidator(
                                            errorText: 'Field cannot be empty'),
                                        EmailValidator(
                                            errorText: 'Enter Valid Email')
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: spaceheight,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    TextButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                        child: const Text("Cancel")),
                                    TextButton(
                                      onPressed: () async {
                                        if (_emailKey.currentState!
                                            .validate()) {
                                          await resendOTP(_email.text);
                                          await getAlertDialog(
                                              context, 'Alert', errormsg);
                                          Navigator.of(context).pop();
                                        }
                                        //Function will be here
                                      },
                                      child: const Text("Send"),
                                    ),
                                  ],
                                )
                              ],
                            );
                          });
                    },
                    child: const Text('Resend OTP'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
