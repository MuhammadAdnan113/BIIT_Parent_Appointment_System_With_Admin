import 'package:form_field_validator/form_field_validator.dart';
import '../../Models/Models.dart';
import '../../Variables/Variables.dart';
import '/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SignupParent extends StatefulWidget {
  const SignupParent({Key? key}) : super(key: key);

  @override
  State<SignupParent> createState() => _SignupParentState();
}

class _SignupParentState extends State<SignupParent> {
  TextEditingController _username = TextEditingController();
  TextEditingController _email = TextEditingController();
  TextEditingController _cnic = TextEditingController();
  TextEditingController _phone = TextEditingController();
  TextEditingController _password = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    errormsg = '';
  }

//=====API Variables=====
  late UserData userdata;
  String errormsg = '';
//========= API ==============

  Future<void> signupData(UserData userdata) async {
    String url = '${Variables.baseurl}/User/Signup';
    var response = await http.post(Uri.parse(url), body: {
      "userName": userdata.username,
      "email": userdata.email,
      "password": userdata.password,
      "regNo": userdata.regno,
      "cnic": userdata.cnic,
      "role": userdata.role,
      "phone": userdata.phone,
      "verify": userdata.verify.toString()
    });
    if (response.statusCode == 200) {
      setState(() {
        errormsg = response.body;
      });
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }
  //======== End API ===========

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Parent Signup'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(
              left: mywidth * 0.10, right: mywidth * 0.10, top: mywidth * 0.04),
          child: Column(
            children: [
              SizedBox(
                height: spaceheight,
              ),
              Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    getTextFormField(
                      hintText: 'User Name',
                      controller: _username,
                      lbltext: 'User Name',
                      maxlength: 9,
                      inputType: TextInputType.text,
                      suffixIcon: const Icon(
                        Icons.person,
                        color: Colors.orange,
                      ),
                      validator: MultiValidator([
                        RequiredValidator(errorText: 'Field cannot be empty')
                      ]),
                    ),
                    SizedBox(
                      height: spaceheight,
                    ),
                    getTextFormField(
                      hintText: 'Email',
                      controller: _email,
                      lbltext: 'Enter Email',
                      maxlength: 25,
                      inputType: TextInputType.emailAddress,
                      suffixIcon: const Icon(
                        Icons.email,
                        color: Colors.redAccent,
                      ),
                      validator: MultiValidator(
                        [
                          RequiredValidator(errorText: 'Field cannot be empty'),
                          EmailValidator(errorText: 'Enter Valid Email')
                        ],
                      ),
                    ),
                    SizedBox(
                      height: spaceheight,
                    ),
                    getTextFormField(
                      hintText: 'CNIC',
                      controller: _cnic,
                      lbltext: 'Enter CNIC',
                      maxlength: 13,
                      inputType: TextInputType.number,
                      suffixIcon: const Icon(
                        Icons.card_membership,
                        color: Colors.redAccent,
                      ),
                      validator: MultiValidator([
                        RequiredValidator(errorText: 'Field cannot be empty'),
                        MinLengthValidator(13,
                            errorText: '13 digits are Required')
                      ]),
                    ),
                    SizedBox(
                      height: spaceheight,
                    ),
                    getTextFormField(
                      hintText: 'Phone',
                      controller: _phone,
                      lbltext: 'Enter Phone',
                      maxlength: 11,
                      inputType: TextInputType.number,
                      suffixIcon: const Icon(
                        Icons.phone,
                        color: Colors.redAccent,
                      ),
                      validator: MultiValidator([
                        RequiredValidator(errorText: 'Field cannot be empty'),
                        MinLengthValidator(11,
                            errorText:
                                'Start with 03 and 11 digits are Required'),
                      ]),
                    ),
                    SizedBox(
                      height: spaceheight,
                    ),
                    getTextFormField(
                        hintText: 'Password',
                        controller: _password,
                        lbltext: 'Enter Password',
                        maxlength: 10,
                        inputType: TextInputType.text,
                        suffixIcon: const Icon(
                          Icons.lock,
                          color: Colors.redAccent,
                        ),
                        validator: MultiValidator(
                          [
                            RequiredValidator(
                                errorText: 'Field cannot be empty'),
                            PatternValidator(r'(?=.*?[#?!@$%^&*-])',
                                errorText: 'At least one special character')
                          ],
                        ),
                        obscureText: true),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    userdata = UserData(
                        1,
                        _username.text,
                        _email.text,
                        _cnic.text,
                        'null',
                        _phone.text,
                        _password.text,
                        'Parent',
                        0);
                    userdata.toMap();
                    await signupData(userdata);
                    await getAlertDialog(context, 'Alert', errormsg);
                  }
                },
                child: const Text('Signup'),
              ),
              Row(
                children: [
                  const Text('Already have an Account?'),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: const Text('Login'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
