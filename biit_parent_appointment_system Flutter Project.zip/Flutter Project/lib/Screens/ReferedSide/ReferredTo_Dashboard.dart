import 'dart:convert';
import 'dart:ui';

import 'package:biit_parent_appointment_system/API/APIHandler.dart';
import 'package:biit_parent_appointment_system/Models/AdminDetailModel.dart';
import 'package:biit_parent_appointment_system/Models/HistoryModel.dart';
import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Screens/AdminSide/Admin_Availability.dart';
import 'package:biit_parent_appointment_system/Screens/ReferedSide/AdminDetail.dart';
import 'package:biit_parent_appointment_system/Screens/ReferedSide/Referred_History.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Referred_Notification.dart';

class ReferDashboard extends StatefulWidget {
  int? notifications;
  final UserData user;
  ReferDashboard({Key? key, required this.notifications, required this.user})
      : super(key: key);

  @override
  State<ReferDashboard> createState() => _ReferDashboardState();
}

class _ReferDashboardState extends State<ReferDashboard> {
//=====API Variables=====
  List<NotificationModel> notifications = [];
  bool success = false;
  String errormsg = '';

  //========= API ========================
  Future<void> getNotification(String admin) async {
    String url = '${Variables.baseurl}/Admin/GetNotification?adminid=$admin';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      notifications = listt.map((e) => NotificationModel.fromJson(e)).toList();
      setState(() {
        success = true;
      });
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

//==================================

  List<HistoryModel> history = [];

  Future<void> apiGetHistory(String admin) async {
    String url = '${Variables.baseurl}/Admin/GetHistory?adminid=$admin';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      history = listt.map((e) => HistoryModel.fromJson(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  //==============================

  List<TimeSlot> timelist = [];
  Future<void> apiGetTimeSlot() async {
    String url =
        '${Variables.baseurl}/admin/GetTimeSlot?adminid=${widget.user.cnic}';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      timelist = listt.map((e) => TimeSlot.fromMap(e)).toList();
      setState(() {});
    } else {
      setState(() {
        errormsg = response.body;
      });
    }
  }

  List<AdminDetailModel> admindetail = [];
  Future<void> apiGetAdminDetail() async {
    String url = '${Variables.baseurl}/refer/GetAdminDetails';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Iterable listt = jsonDecode(response.body);
      admindetail = listt.map((e) => AdminDetailModel.fromJson(e)).toList();
      setState(() {});
    } else {
      getAlertDialog(context, 'Alert', response.body);
    }
  }
  //====== API ===============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('Welcome '),
          Text(
            widget.user.username,
            style: const TextStyle(
                fontSize: 22.0,
                fontWeight: FontWeight.bold,
                color: Colors.black),
          )
        ]),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () async {
              await getcountNotification('Admin', widget.user.cnic);
              if (getResponse.statusCode == 200) {
                widget.notifications = int.parse(response.body);
                setState(() {});
              }
            },
            icon: const Icon(Icons.refresh),
          ),
          Stack(
            children: [
              IconButton(
                  onPressed: () async {
                    await getNotification(widget.user.cnic);
                    if (success) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (cont) => ReferredNotification(
                              notification: notifications)));
                    } else {
                      showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (cont) {
                            return AlertDialog(
                              title: const Text("Alert!"),
                              content: Text(errormsg),
                              actions: [
                                TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text("Ok")),
                              ],
                            );
                          });
                    }
                  },
                  icon: const Icon(
                    Icons.notifications,
                    size: 35,
                  )),
              Positioned(
                left: 22,
                bottom: 22,
                child: Text(
                  '${widget.notifications}',
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
          const SizedBox(
            width: 10,
          ),
        ],
      ),
      body: WillPopScope(
        onWillPop: () => showLogOutDialog(context),
        child: SingleChildScrollView(
          child: Container(
            alignment: Alignment.center,
            margin: EdgeInsets.only(top: mywidth * 0.08),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    await apiGetTimeSlot();
                    if (timelist.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => Availability(
                              user: widget.user, timelist: timelist)));
                    } else {
                      getAlertDialog(context, "Alert", "No TimeSlot Found");
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text('My Schedule'),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                ElevatedButton(
                  onPressed: () async {
                    await apiGetHistory(widget.user.getCnic);
                    if (history.isNotEmpty) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => ReferredHistory(
                                notification: history,
                              )));
                    } else {
                      getAlertDialog(context, 'Alert', errormsg);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(200, 37)),
                  child: const Text("History"),
                ),
                SizedBox(
                  height: spaceheight,
                ),
                widget.user.role == "Director"
                    ? ElevatedButton(
                        onPressed: () async {
                          await apiGetAdminDetail();
                          if (admindetail.isNotEmpty) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => AdminDetail(
                                      detail: admindetail,
                                    )));
                          }
                        },
                        style: ElevatedButton.styleFrom(
                            minimumSize: const Size(200, 37)),
                        child: const Text('Admin Details'),
                      )
                    : const SizedBox(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
