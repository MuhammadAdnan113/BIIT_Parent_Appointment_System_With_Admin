import 'package:biit_parent_appointment_system/Models/AdminDetailModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class AdminDetail extends StatefulWidget {
  List<AdminDetailModel> detail;
  AdminDetail({Key? key, required this.detail}) : super(key: key);

  @override
  State<AdminDetail> createState() => _AdminDetailState();
}

class _AdminDetailState extends State<AdminDetail> {
  double emojiRating = 0;

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Details'),
      ),
      body: widget.detail.isEmpty
          ? const Center(
              child: Text(
                'No Record Exist',
                style: TextStyle(color: Colors.red),
              ),
            )
          : SingleChildScrollView(
              child: Container(
                height: myheight * 0.87,
                margin: EdgeInsets.all(spacewidth),
                child: ListView.builder(
                  itemCount: widget.detail.length,
                  itemBuilder: ((context, index) {
                    AdminDetailModel item = widget.detail.elementAt(index);
                    return Column(
                      children: [
                        Row(
                          children: [
                            const Text(
                              'Full Name:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text('${item.firstName} ${item.lastName}')
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'Email:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.email)
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'designation:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text(item.role)
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          children: [
                            const Text(
                              'Attained Appointments:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth,
                            ),
                            Text('${item.noOfAppointments}')
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              'Attentive:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),

                            Center(
                              child: RatingBar.builder(
                                initialRating: item.attentive,
                                minRating: 0,
                                unratedColor: Colors.grey,
                                itemCount: 5,
                                itemSize: 30.0,
                                itemPadding:
                                    const EdgeInsets.symmetric(horizontal: 4.0),
                                updateOnDrag: false,
                                itemBuilder: (context, index) => const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                onRatingUpdate: (ratingvalue) {},
                              ),
                            ),
                            //Text('${item.attentive.round()}'),
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              'Polite:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: spacewidth * 1.5,
                            ),
                            Center(
                              child: RatingBar.builder(
                                initialRating: item.polite,
                                minRating: 0,
                                unratedColor: Colors.grey,
                                itemCount: 5,
                                itemSize: 30.0,
                                itemPadding:
                                    const EdgeInsets.symmetric(horizontal: 4.0),
                                updateOnDrag: false,
                                itemBuilder: (context, index) => const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                onRatingUpdate: (_) {},
                              ),
                            ),
                            //Text('${item.attentive.round()}'),
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              'Rudness:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),

                            Center(
                              child: RatingBar.builder(
                                initialRating: item.rudness,
                                minRating: 0,
                                unratedColor: Colors.grey,
                                itemCount: 5,
                                itemSize: 30.0,
                                itemPadding:
                                    const EdgeInsets.symmetric(horizontal: 4.0),
                                updateOnDrag: false,
                                itemBuilder: (context, index) => const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                onRatingUpdate: (ratingvalue) {},
                              ),
                            ),
                            //Text('${item.attentive.round()}'),
                          ],
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        SizedBox(
                          height: spaceheight * 0.30,
                        ),
                        const Divider(
                          thickness: 2,
                        ),
                      ],
                    );
                  }),
                ),
              ),
            ),
    );
  }
}
