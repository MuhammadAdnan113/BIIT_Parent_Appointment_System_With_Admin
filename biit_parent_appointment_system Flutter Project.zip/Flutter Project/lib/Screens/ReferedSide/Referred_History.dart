import 'dart:convert';

import 'package:biit_parent_appointment_system/Models/Feedback.dart';
import 'package:biit_parent_appointment_system/Models/HistoryModel.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:http/http.dart' as http;

class ReferredHistory extends StatefulWidget {
  List<HistoryModel> notification;
  ReferredHistory({Key? key, required this.notification}) : super(key: key);

  @override
  State<ReferredHistory> createState() => ReferredHistoryState();
}

class ReferredHistoryState extends State<ReferredHistory> {
//==== API =================
  late FeedbackModel feedback;
  Future<void> getRating(int hid) async {
    String url = '${Variables.baseurl}/Parent/GetRating?hid=$hid';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      feedback = FeedbackModel.fromJson(json.decode(response.body));
      await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (cont) {
            return AlertDialog(
              scrollable: true,
              title: const Text('Rating'),
              content: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      const Text("Attentive"),
                      RatingBar.builder(
                        initialRating: feedback.attentive.toDouble(),
                        minRating: 0,
                        unratedColor: Colors.grey,
                        itemCount: 5,
                        itemSize: 30.0,
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 4.0),
                        updateOnDrag: true,
                        itemBuilder: (context, index) => const Icon(
                          Icons.star,
                          color: Colors.amber,
                        ),
                        onRatingUpdate: (ratingvalue) {},
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text("Polite"),
                      const SizedBox(
                        width: 21,
                      ),
                      RatingBar.builder(
                        initialRating: feedback.polite.toDouble(),
                        minRating: 0,
                        unratedColor: Colors.grey,
                        itemCount: 5,
                        itemSize: 30.0,
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 4.0),
                        updateOnDrag: true,
                        itemBuilder: (context, index) => const Icon(
                          Icons.star,
                          color: Colors.amber,
                        ),
                        onRatingUpdate: (ratingvalue) {},
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text("Rudness"),
                      RatingBar.builder(
                        initialRating: feedback.rudness.toDouble(),
                        minRating: 0,
                        unratedColor: Colors.grey,
                        itemCount: 5,
                        itemSize: 30.0,
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 4.0),
                        updateOnDrag: true,
                        itemBuilder: (context, index) => const Icon(
                          Icons.star,
                          color: Colors.amber,
                        ),
                        onRatingUpdate: (ratingvalue) {},
                      ),
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: const Text("Ok")),
              ],
            );
          });
    } else {
      getAlertDialog(context, "Alert", response.body);
    }
  }
  //=== END API ==============

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Appointments Record'),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: myheight - 100,
          margin: EdgeInsets.all(spacewidth),
          child: ListView.builder(
            itemCount: widget.notification.length,
            itemBuilder: ((context, index) {
              HistoryModel item = widget.notification.elementAt(index);
              return Column(
                children: [
                  Row(
                    children: [
                      const Text(
                        'Reg. No:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.regNo)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Reason:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.reason)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Date:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.date)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Start Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.startTime)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'End Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.endTime),
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Your Remarks:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(item.adminFeedback),
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Suggestion:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(
                        item.suggestion,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 20,
                      ),
                      //============
                      item.suggestion == "N/A"
                          ? const Text("No Feedback from Parent")
                          : ElevatedButton.icon(
                              onPressed: () async {
                                await getRating(item.hid);
                              },
                              icon: const Icon(Icons.remove_red_eye),
                              label: const Text("View Rating"))
                      //============
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  const Divider(
                    thickness: 2,
                  ),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
