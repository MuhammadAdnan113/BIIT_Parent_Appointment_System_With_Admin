import 'dart:convert';
import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:biit_parent_appointment_system/Models/NotificationModel.dart';
import 'package:biit_parent_appointment_system/Variables/Variables.dart';
import 'package:biit_parent_appointment_system/Widgets/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:http/http.dart' as http;

class ReferredNotification extends StatefulWidget {
  List<NotificationModel> notification;
  ReferredNotification({Key? key, required this.notification})
      : super(key: key);

  @override
  State<ReferredNotification> createState() => ReferredNotificationState();
}

class ReferredNotificationState extends State<ReferredNotification> {
  NotificationModel? appointment;
  TextEditingController _remark = TextEditingController(text: '');
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  //===== API==========
  String errormsg = '';
  bool changes = false;

  Future<void> updateMeetingStatus(
      int mid, String status, String remarks) async {
    String url =
        '${Variables.baseurl}/Refer/UpdateMeetingStatus?mid=$mid&status=$status&remarks=$remarks';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      await getAlertDialog(context, 'Alert', response.body);
      setState(() {
        changes = true;
      });
    } else {
      getAlertDialog(context, 'Alert', response.body);
    }
  }

  Future<void> deleteMeeting(int mid) async {
    String url = '${Variables.baseurl}/Refer/DeleteMeeting?mid=$mid';
    var response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      await getAlertDialog(context, 'Alert', response.body);
      setState(() {
        changes = true;
      });
    } else {
      getAlertDialog(context, 'Alert', response.body);
    }
  }

  //==== END API ==========================

  @override
  Widget build(BuildContext context) {
    double mywidth = MediaQuery.of(context).size.width;
    double myheight = MediaQuery.of(context).size.height;
    double spaceheight = myheight * 0.02;
    double spacewidth = mywidth * 0.03;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: myheight * 0.87,
          margin: EdgeInsets.all(spacewidth),
          child: ListView.builder(
            itemCount: widget.notification.length,
            itemBuilder: ((context, index) {
              NotificationModel item = widget.notification.elementAt(index);
              return Column(
                children: [
                  Row(
                    children: [
                      const Text(
                        'Reg. No:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).regNo)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Reason:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).reason)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Date:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).date)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Start Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).startTime)
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'End Time:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Text(widget.notification.elementAt(index).endTime),
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  Row(
                    children: [
                      const Text(
                        'Refer to:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: spacewidth,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          ElevatedButton(
                            onPressed: () async {
                              await showDialog(
                                  context: context,
                                  barrierDismissible: false,
                                  builder: (cont) {
                                    return AlertDialog(
                                      title: const Text("Appointment Remarks"),
                                      actions: [
                                        Form(
                                          key: _formKey,
                                          child: getTextFormField(
                                            hintText: 'Enter Remarks',
                                            controller: _remark,
                                            lbltext:
                                                'Remarks about appointment',
                                            maxlength: 40,
                                            inputType:
                                                TextInputType.emailAddress,
                                            suffixIcon: const Icon(
                                              Icons.email,
                                              color: Colors.redAccent,
                                            ),
                                            validator: MultiValidator(
                                              [
                                                RequiredValidator(
                                                    errorText:
                                                        'Field cannot be empty'),
                                              ],
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          height: spaceheight,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            TextButton(
                                              onPressed: () async {
                                                if (_formKey.currentState!
                                                    .validate()) {
                                                  await updateMeetingStatus(
                                                      item.nid,
                                                      'Feedback',
                                                      _remark.text);
                                                  Navigator.of(context).pop();
                                                  if (changes) {
                                                    widget.notification
                                                        .remove(item);
                                                    setState(() {});
                                                  }
                                                }

                                                //Function will be here
                                              },
                                              child: const Text("Update"),
                                            ),
                                          ],
                                        )
                                      ],
                                    );
                                  });
                            },
                            style: ElevatedButton.styleFrom(
                                minimumSize: const Size(90, 37)),
                            child: const Text('Held'),
                          ),
                          SizedBox(
                            width: spacewidth,
                          ),
                          ElevatedButton(
                            onPressed: () async {
                              await showDialog(
                                  context: context,
                                  barrierDismissible: false,
                                  builder: (cont) {
                                    return AlertDialog(
                                      title: const Text("Appointment Remarks"),
                                      actions: [
                                        Form(
                                          key: _formKey,
                                          child: getTextFormField(
                                            hintText: 'Enter Remarks',
                                            controller: _remark,
                                            lbltext:
                                                'Remarks about appointment',
                                            maxlength: 40,
                                            inputType:
                                                TextInputType.emailAddress,
                                            suffixIcon: const Icon(
                                              Icons.email,
                                              color: Colors.redAccent,
                                            ),
                                            validator: MultiValidator(
                                              [
                                                RequiredValidator(
                                                    errorText:
                                                        'Field cannot be empty'),
                                              ],
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          height: spaceheight,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            TextButton(
                                              onPressed: () async {
                                                if (_formKey.currentState!
                                                    .validate()) {
                                                  await updateMeetingStatus(
                                                      item.nid,
                                                      'Not Held',
                                                      _remark.text);
                                                  Navigator.of(context).pop();
                                                  if (changes) {
                                                    widget.notification
                                                        .remove(item);
                                                    setState(() {});
                                                  }
                                                }

                                                //Function will be here
                                              },
                                              child: const Text("Update"),
                                            ),
                                          ],
                                        )
                                      ],
                                    );
                                  });
                            },
                            style: ElevatedButton.styleFrom(
                                minimumSize: const Size(90, 37)),
                            child: const Text('Not Held'),
                          ),
                          SizedBox(
                            width: spacewidth,
                          ),
                          ElevatedButton(
                            onPressed: () async {
                              await deleteMeeting(item.nid);
                              if (changes) {
                                widget.notification.remove(item);
                                setState(() {});
                              }
                            },
                            style: ElevatedButton.styleFrom(
                                minimumSize: const Size(90, 37)),
                            child: const Text('Cancel'),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: spaceheight * 0.30,
                  ),
                  const Divider(
                    thickness: 2,
                  ),
                ],
              );
            }),
            shrinkWrap: true,
          ),
        ),
      ),
    );
  }
}
