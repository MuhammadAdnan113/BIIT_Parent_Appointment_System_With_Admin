import 'dart:convert';
import 'package:biit_parent_appointment_system/Models/AttendanceModel.dart';
import 'package:biit_parent_appointment_system/Models/CGPAModel.dart';
import 'package:biit_parent_appointment_system/Models/DisciplenaryModel.dart';
import 'package:biit_parent_appointment_system/Models/HistoryModel.dart';
import 'package:biit_parent_appointment_system/Models/WaitingModel.dart';
import 'package:http/http.dart' as http;

import '../Models/Models.dart';
import '../Models/NotificationModel.dart';
import '../Variables/Variables.dart';

//=====API Variables==========
late http.Response response;
String _errormsg = '';
var apiData;
//========= API ==============

Future<void> signupUser(UserData userdata) async {
  response =
      await http.post(Uri.parse("${Variables.baseurl}/User/Signup"), body: {
    "user_name": userdata.username,
    "email": userdata.email,
    "password": userdata.password,
    "reg_no": userdata.regno,
    "cnic": userdata.cnic,
    "role": userdata.role,
    "phone": userdata.phone,
    "verify": userdata.verify.toString()
  });
}

//======================================

//========= API ========================
Future<void> getParentNotification(String controller, String id) async {
  String url = '${Variables.baseurl}/$controller/GetNotification?pcnic=$id';
  response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Iterable listt = jsonDecode(response.body);
    apiData = listt.map((e) => NotificationModel.fromJson(e)).toList();
  }
}

//======================================

Future<void> getcountNotification(String controller, String id) async {
  String url = '${Variables.baseurl}/$controller/countnotification?id=$id';
  response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    apiData = jsonDecode(response.body);
  }
}

//======== Get Response ===============

Future<void> apiGetShortAttendance() async {
  String url = '${Variables.baseurl}/admin/GetShortAttendance';
  response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Iterable listt = jsonDecode(response.body);
    apiData = listt.map((e) => AttendanceModel.fromJson(e)).toList();
  }
}

Future<void> apiGetLowCGPA() async {
  String url = '${Variables.baseurl}/admin/GetLowCGPAStudents';
  response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Iterable listt = jsonDecode(response.body);
    apiData = listt.map((e) => CGPAModel.fromJson(e)).toList();
  }
}

Future<void> apiGetCompletedMeetings(String admin) async {
  String url = '${Variables.baseurl}/Admin/GetCompletedMeeting?admin=$admin';
  response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Iterable listt = jsonDecode(response.body);
    apiData = listt.map((e) => NotificationModel.fromJson(e)).toList();
  }
}

Future<void> apiGetDisciplinary() async {
  String url = '${Variables.baseurl}/admin/GetDisciplenary';
  response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Iterable listt = jsonDecode(response.body);
    apiData = listt.map((e) => DisciplinaryModel.fromJson(e)).toList();
  }
}

Future<void> countRequests() async {
  String url = '${Variables.baseurl}/Admin/CountRequests';
  response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    apiData = int.parse(response.body);
  }
}
//============

Future<void> apiGetHistory(String id) async {
  String url = '${Variables.baseurl}/Parent/GetHistory?id=$id';
  var response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Iterable listt = jsonDecode(response.body);
    apiData = listt.map((e) => HistoryModel.fromJson(e)).toList();
  }
}

Future<void> apiGetWaitingList(String id) async {
  String url = '${Variables.baseurl}/Parent/GetWaitingList?id=$id';
  var response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Iterable listt = jsonDecode(response.body);
    apiData = listt.map((e) => WaitingModel.fromJson(e)).toList();
  }
}

//==================

http.Response get getResponse => response;

dynamic get getAPIData => apiData;
