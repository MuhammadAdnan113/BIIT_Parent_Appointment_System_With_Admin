import 'package:biit_parent_appointment_system/Models/Models.dart';
import 'package:intl/intl.dart';

class Variables {
  // loged In User id
  static String _id = "";
  static void setLoginID(String id) {
    _id = id;
  }

  static get getLoginID => _id;
  // Getting System Date and Formator
  static var nowDate = DateTime.now();
  static var formatter = DateFormat('d/M/yyyy');
  static String systemDate = formatter.format(nowDate);

// Base url Used in every API Call
  static const String baseurl =
      "http://192.168.15.104/BIIT_Parent_Appointment/api";

//==== FUNCTIONS ================
// Removing Duplicate Timeslots
  static List<TimeSlot> removeDuplicateTimeslot(List<TimeSlot> ts) {
    var seen = Set<String>();
    List<TimeSlot> uniquelist =
        ts.where((timeslot) => seen.add(timeslot.startTime)).toList();
    return uniquelist;
  }
}
