import 'package:flutter/material.dart';

TextFormField getTextFormField({
  required String? hintText,
  required TextEditingController? controller,
  required String? lbltext,
  required int? maxlength,
  required TextInputType? inputType,
  required Icon? suffixIcon,
  required String? Function(String?)? validator,
  bool obscureText = false,
}) {
  return TextFormField(
    controller: controller,
    obscureText: obscureText,
    autovalidateMode: AutovalidateMode.onUserInteraction,
    maxLength: maxlength,
    keyboardType: inputType,
    validator: validator,
    decoration: InputDecoration(
      hintText: hintText,
      labelText: lbltext,
      suffixIcon: suffixIcon,
      border: const OutlineInputBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(10),
        ),
      ),
    ),
  );
}

//========= Alert Dialog =================
Future<dynamic> getAlertDialog(
    BuildContext context, String title, String errormessage) {
  return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (cont) {
        return AlertDialog(
          title: Text(title),
          content: Text(errormessage),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text("Ok")),
          ],
        );
      });
}

//============ Logout Dialog ======================

Future<bool> showLogOutDialog(BuildContext context) async {
  return await showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) => AlertDialog(
            title: const Text("LogOut"),
            content: const Text("Do you want to LogOut?"),
            actions: [
              TextButton.icon(
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                  icon: const Icon(Icons.cancel),
                  label: const Text('No')),
              TextButton.icon(
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                  icon: const Icon(Icons.logout),
                  label: const Text('Yes')),
            ],
          ));
}

GestureDetector getCardWithImage(double myheight, double mywidth, String text,
    String imgpath, Function() ontap) {
  return GestureDetector(
    onTap: ontap,
    child: Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 5,
            blurRadius: 7,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          SizedBox(
            width: mywidth * 0.325,
            child: Image.asset(
              imgpath,
              fit: BoxFit.cover,
              height: myheight * 0.20,
              width: mywidth * 0.3,
            ),
          ),
          Container(
            width: mywidth * 0.40,
            decoration: const BoxDecoration(
                color: Colors.blueAccent,
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(12),
                    bottomLeft: Radius.circular(12))),
            padding: const EdgeInsets.all(12),
            child: Center(
                child: Text(
              text,
              style: TextStyle(color: Colors.white),
            )),
          )
        ],
      ),
    ),
  );
}
