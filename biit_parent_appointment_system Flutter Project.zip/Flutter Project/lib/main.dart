import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';

import 'Screens/Authentication/Login_Screen.dart';
import 'Screens/Authentication/Onboarding.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();

  final showHome = prefs.getBool("showHome") ?? false;
  runApp(MyApp(showHome: showHome));
}

class MyApp extends StatelessWidget {
  final bool showHome;
  const MyApp({Key? key, required this.showHome}) : super(key: key);
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BIIT Parent Appointment',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: showHome ? const Login() : const onboarding(),
    );
  }
}
