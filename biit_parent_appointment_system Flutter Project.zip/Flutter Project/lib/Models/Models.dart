import 'package:flutter/material.dart';

class UserData {
  late int id;
  late String username;
  late String email;
  late String cnic;
  late String regno;
  late String phone;
  late String password;
  late String role;
  late int verify;

  UserData(this.id, this.username, this.email, this.cnic, this.regno,
      this.phone, this.password, this.role, this.verify);

  get getId => id;

  get getUsername => username;

  get getEmail => email;

  get getCnic => cnic;

  get getRegno => regno;

  get getPhone => phone;

  get getPassword => password;

  get getRole => role;

  get getVerify => verify;

  Map<String, dynamic> toMap() {
    Map<String, dynamic> mp = <String, dynamic>{};
    mp['id'] = id;
    mp['userName'] = username;
    mp['email'] = email;
    mp['password'] = password;
    mp['regNo'] = regno;
    mp['cnic'] = cnic;
    mp['role'] = role;
    mp['phone'] = phone;
    mp['verify'] = verify;
    return mp;
  } // end to map

  UserData.fromMap(Map<String, dynamic> mp) {
    id = mp['id'];
    username = mp['userName'];
    email = mp['email'];
    password = mp['password'];
    regno = mp['regNo'] ?? '0';
    cnic = mp['cnic'];
    role = mp['role'];
    phone = mp['phone'] ?? '0';
    verify = mp['verify'];
  } // end from map

} // end UserData class

//========== TimeSlot ===============
class TimeSlot {
  late int tsid;
  late String day;
  late String startTime;
  late String endTime;
  late String adminId;
  late bool? availability;

  TimeSlot(this.tsid, this.day, this.startTime, this.endTime, this.adminId,
      this.availability);

  Map<String, dynamic> toMap() {
    Map<String, dynamic> mp = <String, dynamic>{};
    mp['tsid'] = tsid;
    mp['day'] = day;
    mp['startTime'] = startTime;
    mp['endTime'] = endTime;
    mp['adminId'] = adminId;
    mp['availability'] = availability;
    return mp;
  } // end to map

  TimeSlot.fromMap(Map<String, dynamic> mp) {
    tsid = mp['tsid'];
    day = mp['day'];
    startTime = mp['startTime'];
    endTime = mp['endTime'];
    adminId = mp['adminId'];
    availability = mp['availability'] ?? null;
  } // end from map

}// end TimeSlot class
