class DisciplinaryModel {
  int? id;
  String? regNo;
  String? class1;
  int? semester;
  String? section;
  String? actions;

  DisciplinaryModel(
      {this.id,
      this.regNo,
      this.class1,
      this.semester,
      this.section,
      this.actions});

  DisciplinaryModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    regNo = json['regNo'];
    class1 = json['class'];
    semester = json['semester'];
    section = json['section'];
    actions = json['actions'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['regNo'] = regNo;
    data['class'] = class1;
    data['semester'] = semester;
    data['section'] = section;
    data['actions'] = actions;
    return data;
  }
}
