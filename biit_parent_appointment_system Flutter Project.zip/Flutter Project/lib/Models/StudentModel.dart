class StudentModel {
  String? regNo;
  String? firstName;
  String? lastName;
  String? email;
  String? gender;
  String? birthDate;
  String? scnic;
  String? pcnic;
  int? semester;
  String? clas;
  String? section;

  StudentModel(
      {this.regNo,
      this.firstName,
      this.lastName,
      this.email,
      this.gender,
      this.birthDate,
      this.scnic,
      this.pcnic,
      this.semester,
      this.clas,
      this.section});

  StudentModel.fromJson(Map<String, dynamic> json) {
    regNo = json['regNo'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    gender = json['gender'];
    birthDate = json['birthDate'];
    scnic = json['studentCNIC'];
    pcnic = json['parentCNIC'];
    semester = json['semester'];
    clas = json['class'];
    section = json['section'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['regNo'] = regNo;
    data['firstName'] = firstName;
    data['lastName'] = lastName;
    data['email'] = email;
    data['gender'] = gender;
    data['birthDate'] = birthDate;
    data['studentCNIC'] = scnic;
    data['parentCNIC'] = pcnic;
    data['semester'] = semester;
    data['class'] = clas;
    data['section'] = section;
    return data;
  }
}
