class AttendanceModel {
  late int sid;
  late String regNo;
  late String subject;
  late String class1;
  late int semester;
  late String section;
  late int percentage;

  AttendanceModel(this.sid, this.regNo, this.subject, this.class1,
      this.semester, this.section, this.percentage);

  AttendanceModel.fromJson(Map<String, dynamic> json) {
    sid = json['sid'];
    regNo = json['regNo'];
    subject = json['subject'];
    class1 = json['class'];
    semester = json['semester'];
    section = json['section'];
    percentage = json['percentage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sid'] = sid;
    data['regNo'] = regNo;
    data['subject'] = subject;
    data['class'] = class1;
    data['semester'] = semester;
    data['section'] = section;
    data['percentage'] = percentage;
    return data;
  }
}
