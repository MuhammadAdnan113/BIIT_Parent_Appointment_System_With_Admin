class AdminDetailModel {
  late String cnic;
  late String firstName;
  late String lastName;
  late String email;
  late String role;
  late double attentive;
  late double polite;
  late double rudness;
  late int noOfAppointments;

  AdminDetailModel(
      this.cnic,
      this.firstName,
      this.lastName,
      this.email,
      this.role,
      this.attentive,
      this.polite,
      this.rudness,
      this.noOfAppointments);

  AdminDetailModel.fromJson(Map<String, dynamic> json) {
    cnic = json['cnic'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    role = json['role'];
    attentive = json['attentive'];
    polite = json['polite'];
    rudness = json['rudness'];
    noOfAppointments = json['noOfAppointments'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['cnic'] = cnic;
    data['firstName'] = firstName;
    data['lastName'] = lastName;
    data['email'] = email;
    data['role'] = role;
    data['attentive'] = attentive;
    data['polite'] = polite;
    data['rudness'] = rudness;
    data['noOfAppointments'] = noOfAppointments;
    return data;
  }
}
