class RequestModel {
  late int id;
  late String regNo;
  late String reason;
  late String parentId;
  late String date;

  RequestModel(this.id, this.regNo, this.reason, this.parentId, this.date);

  RequestModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    regNo = json['regNo'];
    reason = json['reason'];
    parentId = json['parentId'];
    date = json['date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['regNo'] = regNo;
    data['reason'] = reason;
    data['parentId'] = parentId;
    data['date'] = date;
    return data;
  }
}
