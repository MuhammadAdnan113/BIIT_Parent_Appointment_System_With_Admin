class FeedbackModel {
  late String adminId;
  late double attentive;
  late double polite;
  late double rudness;
  late int hid;

  FeedbackModel(
      this.adminId, this.attentive, this.polite, this.rudness, this.hid);

  FeedbackModel.fromJson(Map<String, dynamic> json) {
    adminId = json['adminId'];
    attentive = json['attentive'];
    polite = json['polite'];
    rudness = json['rudness'];
    hid = json['hid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['adminId'] = adminId;
    data['attentive'] = attentive;
    data['polite'] = polite;
    data['rudness'] = rudness;
    data['hid'] = hid;
    return data;
  }
}
