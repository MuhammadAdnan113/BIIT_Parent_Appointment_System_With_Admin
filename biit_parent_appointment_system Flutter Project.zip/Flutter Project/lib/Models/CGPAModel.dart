class CGPAModel {
  late int id;
  late String regNo;
  late String class1;
  late String section;
  late int semester;
  late double cgpa;

  CGPAModel(
      this.id, this.regNo, this.class1, this.semester, this.section, this.cgpa);

  CGPAModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    regNo = json['regNo'];
    class1 = json['class'];
    semester = json['semester'];
    section = json['section'];
    cgpa = json['cgpa1'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['regNo'] = regNo;
    data['class'] = class1;
    data['semester'] = semester;
    data['section'] = section;
    data['cgpa1'] = cgpa;
    return data;
  }
}
