class WaitingModel {
  late int id;
  late int tsId;
  late String regNo;
  late String date;
  late String reason;
  late String parentId;
  late String adminId;
  late String status;

  WaitingModel(this.id, this.tsId, this.regNo, this.date, this.reason,
      this.parentId, this.adminId, this.status);

  WaitingModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    tsId = json['tsId'];
    regNo = json['regNo'];
    date = json['date'];
    reason = json['reason'];
    parentId = json['parentId'];
    adminId = json['adminId'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['tsId'] = tsId;
    data['regNo'] = regNo;
    data['date'] = date;
    data['reason'] = reason;
    data['parentId'] = parentId;
    data['adminId'] = adminId;
    data['status'] = status;
    return data;
  }
}
