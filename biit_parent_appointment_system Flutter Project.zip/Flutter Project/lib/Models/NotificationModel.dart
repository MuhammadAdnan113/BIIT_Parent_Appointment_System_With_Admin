class NotificationModel {
  late int nid;
  late int tsid;
  late String regNo;
  late String startTime;
  late String endTime;
  late String date;
  late String? feedback;
  late String status;
  late String reason;
  late String admin;
  late String pid;
  late String? referedTo;

  NotificationModel(
      this.nid,
      this.tsid,
      this.regNo,
      this.startTime,
      this.endTime,
      this.date,
      this.feedback,
      this.status,
      this.reason,
      this.admin,
      this.pid,
      this.referedTo);

  NotificationModel.fromJson(Map<String, dynamic> json) {
    nid = json['mid'];
    tsid = json['tsid'];
    regNo = json['regNo'];
    startTime = json['startTime'];
    endTime = json['endTime'];
    date = json['date'];
    feedback = json['feedback'];
    status = json['status'];
    reason = json['reason'];
    admin = json['adminId'];
    pid = json['parentId'];
    referedTo = json['referedTo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['mid'] = nid;
    data['tsid'] = tsid;
    data['regNo'] = regNo;
    data['startTime'] = startTime;
    data['endTime'] = endTime;
    data['date'] = date;
    data['feedback'] = feedback;
    data['status'] = status;
    data['reason'] = reason;
    data['adminId'] = admin;
    data['parentId'] = pid;
    data['referedTo'] = referedTo;
    return data;
  }
}
