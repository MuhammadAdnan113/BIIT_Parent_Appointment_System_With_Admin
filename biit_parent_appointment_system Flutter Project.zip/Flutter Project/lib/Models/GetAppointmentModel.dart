class GetAppointmentModel {
  int? mid;
  int? tsid;
  String? regNo;
  String? reason;
  String? status;
  String? admin;
  String? pid;
  String? date;
  String? startTime;
  String? endTime;
  String? referedTo;

  GetAppointmentModel(
      {this.mid,
      this.tsid,
      this.regNo,
      this.reason,
      this.status,
      this.admin,
      this.pid,
      this.date,
      this.startTime,
      this.endTime,
      this.referedTo});

  GetAppointmentModel.fromJson(Map<String, dynamic> json) {
    mid = json['mid'];
    mid = json['tsid'];
    regNo = json['regNo'];
    reason = json['reason'];
    status = json['status'];
    admin = json['adminId'];
    pid = json['parentId'];
    date = json['date'];
    startTime = json['startTime'];
    endTime = json['endTime'];
    referedTo = json['referedTo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['mid'] = mid;
    data['tsid'] = mid;
    data['regNo'] = regNo;
    data['reason'] = reason;
    data['status'] = status;
    data['adminId'] = admin;
    data['parentId'] = pid;
    data['date'] = date;
    data['startTime'] = startTime;
    data['endTime'] = endTime;
    data['referedTo'] = referedTo;
    return data;
  }
}
