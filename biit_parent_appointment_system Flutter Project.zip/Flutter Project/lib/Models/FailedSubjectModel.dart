class FailedSubjectModel {
  int? id;
  String? regNo;
  String? semester;
  String? subject;
  String? grade;

  FailedSubjectModel(
      {this.id, this.regNo, this.semester, this.subject, this.grade});

  FailedSubjectModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    regNo = json['regNo'];
    semester = json['semester'];
    subject = json['subject'];
    grade = json['grade'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['reg_no'] = regNo;
    data['semester'] = semester;
    data['subject'] = subject;
    data['grade'] = grade;
    return data;
  }
}
