class AppointmentModel {
  late int meetingId;
  late int tsid;
  late String date;
  late String regNo;
  late String reason;
  late String status;
  late String admin;
  late String pid;
  late String referedTo;

  AppointmentModel(this.meetingId, this.tsid, this.date, this.regNo,
      this.reason, this.status, this.admin, this.pid, this.referedTo);

  AppointmentModel.fromJson(Map<String, dynamic> json) {
    meetingId = json['mid'];
    tsid = json['tsid'];
    date = json['date'];
    regNo = json['regNo'];
    reason = json['reason'];
    status = json['status'];
    admin = json['adminId'];
    pid = json['parentId'];
    referedTo = json['referedTo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['mid'] = meetingId;
    data['tsid'] = tsid;
    data['date'] = date;
    data['regNo'] = regNo;
    data['reason'] = reason;
    data['status'] = status;
    data['adminId'].admin;
    data['parentId'] = pid;
    data['referedTo'] = referedTo;
    return data;
  }
}
