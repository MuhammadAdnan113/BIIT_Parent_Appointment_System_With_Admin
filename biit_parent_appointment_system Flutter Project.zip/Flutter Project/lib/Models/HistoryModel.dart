class HistoryModel {
  late int hid;
  late String regNo;
  late String startTime;
  late String endTime;
  late String date;
  late String status;
  late String reason;
  late String adminId;
  late String parentId;
  late String referedTo;
  late String adminFeedback;
  late String suggestion;
  late String parentFullName;
  late String studentFullName;
  late double attentive;
  late double polite;
  late double rudness;

  HistoryModel(
      this.hid,
      this.regNo,
      this.startTime,
      this.endTime,
      this.date,
      this.status,
      this.reason,
      this.adminId,
      this.parentId,
      this.referedTo,
      this.adminFeedback,
      this.suggestion,
      this.parentFullName,
      this.studentFullName,
      this.attentive,
      this.polite,
      this.rudness);

  HistoryModel.fromJson(Map<String, dynamic> json) {
    hid = json['hid'];
    regNo = json['regNo'];
    startTime = json['startTime'];
    endTime = json['endTime'];
    date = json['date'];
    status = json['status'];
    reason = json['reason'];
    adminId = json['adminId'];
    parentId = json['parentId'];
    referedTo = json['referedTo'];
    adminFeedback = json['adminFeedback'];
    suggestion = json['suggestion'] ?? "N/A";
    parentFullName = json['parentFullName'];
    studentFullName = json['studentFullName'];
    attentive = json['attentive'];
    polite = json['polite'];
    rudness = json['rudness'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['hid'] = hid;
    data['regNo'] = regNo;
    data['startTime'] = startTime;
    data['endTime'] = endTime;
    data['date'] = date;
    data['status'] = status;
    data['reason'] = reason;
    data['adminId'] = adminId;
    data['parentId'] = parentId;
    data['referedTo'] = referedTo;
    data['adminFeedback'] = adminFeedback;
    data['suggestion'] = suggestion;
    data['adminId'] = parentFullName;
    data['parentId'] = studentFullName;
    data['referedTo'] = attentive;
    data['adminFeedback'] = polite;
    data['suggestion'] = rudness;
    return data;
  }
}
